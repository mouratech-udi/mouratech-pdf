namespace Mouratech;

internal sealed class Welcome : Form
{
    public Welcome()
    {
        Text="Iniciando Mouratech PDF";FormBorderStyle=FormBorderStyle.None;
        StartPosition=FormStartPosition.CenterScreen;ShowInTaskbar=false;
        AutoScaleMode=AutoScaleMode.Dpi;AutoScaleDimensions=new SizeF(96,96);
        ClientSize=new Size(520,212);BackColor=Brand.Navy;
        using var stream=typeof(Welcome).Assembly.GetManifestResourceStream("Mouratech.Logo")!;
        using var image=Image.FromStream(stream);
        var logo=new PictureBox{Bounds=new Rectangle(0,0,188,208),Padding=new Padding(17),
            SizeMode=PictureBoxSizeMode.Zoom,BackColor=Color.FromArgb(248,248,248),Image=new Bitmap(image),AccessibleName="Logotipo Mouratech"};
        Controls.Add(logo);
        void Line(string value,int y,int height,float size,FontStyle style,Color color)
        {
            Controls.Add(new Label{Text=value,Bounds=new Rectangle(211,y,300,height),ForeColor=color,
                Font=new Font("Segoe UI",size,style),TextAlign=ContentAlignment.MiddleLeft});
        }
        var version=typeof(Welcome).Assembly.GetName().Version!;
        Line("Mouratech PDF",34,46,21,FontStyle.Bold,Color.White);
        Line($"Versão {version.ToString(3)}",82,27,11,FontStyle.Regular,Color.LightSteelBlue);
        Line("Desenvolvido pela Mouratech para seus clientes",120,58,11,FontStyle.Regular,Color.White);
        Controls.Add(new Panel{Dock=DockStyle.Bottom,Height=4,BackColor=Brand.Blue});
        Disposed+=(_,_)=>logo.Image?.Dispose();
    }
}
