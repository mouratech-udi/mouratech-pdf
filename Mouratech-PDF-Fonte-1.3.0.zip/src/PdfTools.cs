using iText.Forms;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Annot;
using System.Text;
using System.Security.Cryptography;
using Rect=iText.Kernel.Geom.Rectangle;
namespace Mouratech;

internal static class PdfTools
{
    internal static void Editable(PdfDocument doc)
    {
        if(Pages.Locked(doc))throw new UserError("Use um original sem assinatura digital ou proteção para esta operação.");
    }
    internal static byte[] Protect(byte[] bytes,string password)
    {
        var encoded=Encoding.UTF8.GetBytes(password);
        if(encoded.Length is 0 or >127)throw new UserError("Informe uma senha de até 127 bytes em UTF-8.");
        using(var check=Pages.Read(bytes))Editable(check);
        using var output=new MemoryStream();
        var props=new WriterProperties().SetStandardEncryption(encoded,RandomNumberGenerator.GetBytes(32),
            EncryptionConstants.ALLOW_PRINTING|EncryptionConstants.ALLOW_COPY,EncryptionConstants.ENCRYPTION_AES_256);
        using(var doc=new PdfDocument(new PdfReader(new MemoryStream(bytes)),new PdfWriter(output,props))){}
        return output.ToArray();
    }
    internal static byte[] Annotate(byte[] bytes,int number,RectangleF selection,string? note)
    {
        using var output=new MemoryStream();
        using(var doc=new PdfDocument(new PdfReader(new MemoryStream(bytes)),new PdfWriter(output),new StampingProperties().UseAppendMode()))
        {
            Editable(doc);
            var page=doc.GetPage(number);var crop=page.GetCropBox();
            PointF Convert(float u,float v)
            {
                (float x,float y)=page.GetRotation() switch{90=>(v,u),180=>(1-u,v),270=>(1-v,1-u),_=>(u,1-v)};
                return new(crop.GetLeft()+x*crop.GetWidth(),crop.GetBottom()+y*crop.GetHeight());
            }
            var a=Convert(selection.Left,selection.Top);var b=Convert(selection.Right,selection.Bottom);
            var r=new Rect(Math.Min(a.X,b.X),Math.Min(a.Y,b.Y),Math.Abs(a.X-b.X),Math.Abs(a.Y-b.Y));
            PdfAnnotation annot;
            if(note==null)
            {
                annot=PdfTextMarkupAnnotation.CreateHighLight(r,[r.GetLeft(),r.GetTop(),r.GetRight(),r.GetTop(),r.GetLeft(),r.GetBottom(),r.GetRight(),r.GetBottom()]);
            }
            else annot=new PdfTextAnnotation(r).SetIconName(PdfName.Note).SetContents(note);
            annot.SetColor(new float[]{1,.86f,.12f});annot.SetFlag(PdfAnnotation.PRINT);page.AddAnnotation(annot);
        }
        return output.ToArray();
    }

    internal sealed record Sheet(byte[] Bytes,string Name,int Page)
    {
        public override string ToString()=>$"{Name}   ·   página {Page}";
    }

    internal static byte[] Assemble(IEnumerable<Sheet> sheets)
    {
        using var output=new MemoryStream();
        var opened=new Dictionary<byte[],PdfDocument>();
        try
        {
            using var dest=new PdfDocument(new PdfWriter(output));
            var copier=new PdfPageFormCopier();
            foreach(var sheet in sheets)
            {
                if(!opened.TryGetValue(sheet.Bytes,out var source))
                {
                    source=Pages.Read(sheet.Bytes);opened.Add(sheet.Bytes,source);Editable(source);
                    if(PdfAcroForm.GetAcroForm(source,false)?.GetAllFormFields().Count>0)
                        throw new UserError("Este PDF contém um formulário interativo. A organização aceita páginas sem campos de formulário.");
                }
                source.CopyPagesTo(sheet.Page,sheet.Page,dest,copier);
            }
            if(dest.GetNumberOfPages()==0)throw new UserError("Escolha pelo menos uma página.");
        }
        finally{foreach(var doc in opened.Values)doc.Close();}
        return output.ToArray();
    }

    internal static void Split(string folder,IEnumerable<Sheet> sheets)
    {
        if(Directory.Exists(folder)||File.Exists(folder))throw new UserError("Já existe uma pasta de partes com esse nome. Escolha outro destino.");
        string temp=Path.Combine(Path.GetDirectoryName(folder)!,"."+Guid.NewGuid());
        Directory.CreateDirectory(temp);
        try
        {
            int index=0;
            foreach(var sheet in sheets)File.WriteAllBytes(Path.Combine(temp,$"parte-{++index:D3}.pdf"),Assemble([sheet]));
            if(index==0)throw new UserError("Escolha pelo menos uma página.");
            Directory.Move(temp,folder);
        }
        finally{if(Directory.Exists(temp))Directory.Delete(temp,true);}
    }
}

