using System.Security.Cryptography.X509Certificates;
using System.Formats.Asn1;

namespace Mouratech;

internal static class Program
{
    [STAThread]
    static int Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        if (args.Length == 2 && args[0] == "--autoteste") return Lab.Run(args[1]);
        using var welcome=new Welcome();
        using var timer=new System.Windows.Forms.Timer{Interval=1400};
        ReaderWindow? reader=null;
        welcome.Shown+=(_,_)=>{
            reader=new ReaderWindow(args.Length==1?args[0]:null);
            timer.Start();
        };
        timer.Tick+=(_,_)=>{timer.Stop();welcome.Close();};
        welcome.ShowDialog();
        if(reader!=null){using(reader)Application.Run(reader);}
        return 0;
    }
}
internal sealed class Desk : Form
{
    readonly Panel preview = new() { Dock = DockStyle.Fill, BackColor = Color.FromArgb(228,235,238) };
    readonly FlowLayoutPanel controls = new(){ Dock=DockStyle.Right, Width=345, Padding=new Padding(18), FlowDirection=FlowDirection.TopDown, WrapContents=false, AutoScroll=true, BackColor=Color.White };
    readonly ComboBox identities = new(){ Width=286, DropDownStyle=ComboBoxStyle.DropDownList };
    readonly CheckBox checkedPlace = new(){Width=286,Height=54,Text="Confirmo que desejo assinar este documento."};
    readonly Label fileLabel = new(){Width=285, Height=42,Text="Nenhum documento aberto"};
    readonly Label status = new(){Width=286,Height=58};
    readonly Button sign;
    Layout? layout;
    string? original;
    Rectangle view;
    readonly byte[] initial, baseline;
    public string? SavedPath { get; private set; }
    readonly string? batchCaption, requiredThumbprint;
    PointF placement=new(.523f,.802f);
    public ReviewedFile? Reviewed {get;private set;}
    public Desk(string path, byte[] bytes, byte[] diskBytes,string? batchCaption=null,string? requiredThumbprint=null)
    {
        original=path; initial=bytes; baseline=diskBytes;
        this.batchCaption=batchCaption;this.requiredThumbprint=requiredThumbprint;
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        Text="Mouratech Assinador Digital";
        Size=new Size(1080,860); MinimumSize=new Size(800,650);
        StartPosition=FormStartPosition.CenterScreen; Font=new Font("Segoe UI",10);
        var header=new Label{Dock=DockStyle.Top, Height=68, Padding=new Padding(20,0,0,0),
            Text="Mouratech   /   Assinador Digital", TextAlign=ContentAlignment.MiddleLeft,
            Font=new Font("Segoe UI Semibold",19), ForeColor=Color.White, BackColor=Brand.Navy};
        Controls.Add(preview); Controls.Add(controls); Controls.Add(header);
        Label Section(string s) => new(){Text=s, AutoSize=true, Font=new Font(Font,FontStyle.Bold), Margin=new Padding(2,16,2,6)};
        controls.Controls.Add(Section("Documento PDF"));
         controls.Controls.Add(fileLabel);
        controls.Controls.Add(Section("Certificado A1 do Windows")); controls.Controls.Add(identities);
        AddButton("Atualizar certificados", Reload);
        controls.Controls.Add(Section("Carimbo na última página"));
        controls.Controls.Add(new Label{Text="Clique na página para posicionar o carimbo logo acima do ponto escolhido.",Width=286,Height=62});
        controls.Controls.Add(status); controls.Controls.Add(checkedPlace);
        sign=AddButton(batchCaption==null?"Assinar e salvar cópia":"Aprovar para o lote", Save);
        Brand.Button(sign,true);preview.BackColor=Brand.Canvas;controls.ForeColor=Brand.Navy;
        if(batchCaption!=null)
        {
            header.Text=batchCaption;
            AddButton("Pular este arquivo",()=>DialogResult=DialogResult.Ignore);
            AddButton("Cancelar lote",()=>DialogResult=DialogResult.Cancel);
        }
        else AddButton("Verificar uma cópia…", Check);
        AddButton("Como validar no ITI", ()=>MessageBox.Show("Para homologar, assine um PDF fictício com o A1 e abra https://validar.iti.gov.br no navegador. Selecione a cópia assinada e confira o titular, a integridade e o relatório. O envio ao portal é uma ação externa e manual.","Validação externa"));
        checkedPlace.CheckedChanged+=(_,_)=>UpdateState();
        identities.SelectedIndexChanged+=(_,_)=>{checkedPlace.Checked=false;UpdateState();};
        preview.Paint+=PaintPage; preview.Resize+=(_,_)=>preview.Invalidate();
        preview.MouseClick+=(_,e)=>{if(layout==null || !view.Contains(e.Location))return;
            placement=new((e.X-view.Left)/(float)view.Width,(e.Y-view.Top)/(float)view.Height);
            layout.Place(placement.X,placement.Y);
            checkedPlace.Checked=false; UpdateState(); preview.Invalidate();};
        Shown+=(_,_)=>Guard(()=>{Open(); Reload();});
        FormClosed+=(_,_)=>{layout?.Dispose(); DisposeIds();}; UpdateState();
    }
    Button AddButton(string text, Action action)
    {
        var button=new Button{Text=text, Width=286, Height=38};
        Brand.Button(button);button.Click+=(_,_)=>Guard(action); controls.Controls.Add(button); return button;
    }
    void Guard(Action action)
    {
        try { UseWaitCursor=true; action(); }
        catch(UserError e){MessageBox.Show(e.Message,Text);}
        catch(Exception){MessageBox.Show("Não foi possível concluir. Confira o PDF, o acesso à pasta e o certificado selecionado.",Text);}
        finally{UseWaitCursor=false;}
    }
    void DisposeIds(){foreach(Identity id in identities.Items) id.Certificate.Dispose(); identities.Items.Clear();}
    void Reload()
    {
        DisposeIds();
        using var store=new X509Store(StoreName.My,StoreLocation.CurrentUser);
        store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);
        foreach(var cert in store.Certificates)
        {
            try{if((requiredThumbprint==null || cert.Thumbprint==requiredThumbprint) && Identity.Eligible(cert)){identities.Items.Add(new Identity(cert));continue;}}
            catch(AsnContentException){}
            cert.Dispose();
        }
        if(identities.Items.Count>0) identities.SelectedIndex=0;
        UpdateState();
    }
    static string? Pick()
    {
        using var dialog=new OpenFileDialog{Filter="Documento PDF (*.pdf)|*.pdf",RestoreDirectory=true};
        return dialog.ShowDialog()==DialogResult.OK ? dialog.FileName : null;
    }
    void Open()
    {
        var path=original!;
        var next=new Layout(initial); next.Place(.523f,.802f);
        layout?.Dispose(); layout=next; original=path; fileLabel.Text=$"{Path.GetFileName(path)}  ·  página {next.Pages} de {next.Pages}";
        checkedPlace.Checked=false; UpdateState(); preview.Invalidate();
    }
    void UpdateState()
    {
        status.Text=layout==null ? "Abra o PDF para conferir a última página." :
            !layout.Safe ? "Posição bloqueada. Clique em uma área livre da página." :
            identities.SelectedItem==null ? "Área livre. Nenhum A1 RSA válido com chave privada disponível." : "Área livre para o carimbo.";
        sign.Enabled=layout?.Safe==true && checkedPlace.Checked && identities.SelectedItem!=null;
    }
    void Save()
    {
        if(layout==null || original==null || !sign.Enabled || identities.SelectedItem is not Identity id)return;
        if(batchCaption!=null)
        {
            Reviewed=new ReviewedFile(original,System.Security.Cryptography.SHA256.HashData(initial),placement,id.Certificate.Thumbprint);
            DialogResult=DialogResult.OK;
            return;
        }
        using var dialog=new SaveFileDialog{Filter="Documento PDF|*.pdf",InitialDirectory=Path.GetDirectoryName(original),FileName=Path.GetFileNameWithoutExtension(original)+"_assinado.pdf",RestoreDirectory=true};
        if(dialog.ShowDialog(this)!=DialogResult.OK)return;
        var path=Signing.Save(original,layout,id.Certificate,dialog.FileName,baseline);
        SavedPath=path;
        MessageBox.Show($"Cópia assinada e integridade conferida.\n\n{path}",Text);
        DialogResult=DialogResult.OK;
    }
    void Check()
    {
        var path=Pick(); if(path==null)return;
        MessageBox.Show(Signing.Verify(File.ReadAllBytes(path)) ?
            "Assinatura Mouratech íntegra. A verificação cobre todo o arquivo. Para avaliar confiança e revogação, consulte o VALIDAR." :
            "A integridade da assinatura Mouratech não foi confirmada.",Text);
    }
    void PaintPage(object? sender, PaintEventArgs e)
    {
        if(layout==null){TextRenderer.DrawText(e.Graphics,"Prévia da última página",Font,preview.ClientRectangle,Color.DimGray,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);return;}
        var page=layout.Page;
        float scale=Math.Min((preview.Width-24f)/page.Width,(preview.Height-24f)/page.Height);
        if(scale<=0)return;
        int w=(int)(page.Width*scale), h=(int)(page.Height*scale);
        view=new((preview.Width-w)/2,(preview.Height-h)/2,w,h); e.Graphics.DrawImage(page,view);
        var b=layout.Box;
        var rect=new RectangleF(view.X+b.X*scale,view.Y+b.Y*scale,b.Width*scale,b.Height*scale);
        e.Graphics.DrawImage(layout.Stamp,rect);
        using var pen=new Pen(layout.Safe?Color.Teal:Color.Red,2);
        e.Graphics.DrawRectangle(pen,rect.X,rect.Y,rect.Width,rect.Height);
    }
}


