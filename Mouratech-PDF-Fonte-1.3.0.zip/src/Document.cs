using iText.Kernel.Pdf;
using iText.Signatures;
using PDFtoImage;
using SkiaSharp;
using System.Drawing.Imaging;

namespace Mouratech;

internal sealed class Layout : IDisposable
{
    public const int WidthPt = 164, HeightPt = 19;
    public readonly byte[] Bytes;
    public readonly int Pages;
    public readonly float Width, Height, Left, Bottom;
    public readonly Bitmap Page;
    public readonly Bitmap Stamp;
    private readonly SKBitmap pixels;
    public Rectangle Box { get; private set; }
    public bool Safe { get; private set; }

    public Layout(byte[] bytes)
    {
        Bytes = bytes;
        using var doc = new PdfDocument(new PdfReader(new MemoryStream(bytes)));
        Pages = doc.GetNumberOfPages();
        var page = doc.GetLastPage();
        var crop = page.GetCropBox();
        Width = crop.GetWidth(); Height = crop.GetHeight(); Left = crop.GetLeft(); Bottom = crop.GetBottom();
        if (doc.GetReader().IsEncrypted() || new SignatureUtil(doc).GetSignatureNames().Count != 0 ||
            page.GetRotation() != 0 || page.GetAnnotations().Count != 0 || page.GetPdfObject().GetAsNumber(PdfName.UserUnit)?.FloatValue() is not (null or 1f) ||
            Width < 200 || Height < 200 || Width > 1200 || Height > 1600 ||
            !crop.EqualsWithEpsilon(page.GetMediaBox()))
            throw new UserError("O MVP requer um PDF sem proteção ou assinaturas, com última página sem rotação, recorte especial ou anotações.");
        pixels = Conversion.ToImage(bytes, Pages - 1, options: new RenderOptions(Dpi: 216));
        using var encoded = pixels.Encode(SKEncodedImageFormat.Png, 100);
        using var input = encoded.AsStream();
        using var bitmap = new Bitmap(input);
        Page = new Bitmap(bitmap);
        Stamp = new Bitmap(WidthPt * 4, HeightPt * 4);
        using var g = Graphics.FromImage(Stamp);
        g.Clear(Color.White);
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
        using var font = new Font("Segoe UI", 33, FontStyle.Regular, GraphicsUnit.Pixel);
        using var ink = new SolidBrush(Color.FromArgb(29, 64, 77));
        g.FillRectangle(ink, 0, 7, 6, Stamp.Height-14);
        g.DrawString("Assinado digitalmente", font, ink, 16, 13);
    }

    // The operator identifies the top of the line or the name. Preserve a 4 pt gap.
    public void Place(float xFraction, float yFraction)
    {
        var sx = pixels.Width / Width;
        var sy = pixels.Height / Height;
        int w = (int)Math.Ceiling(WidthPt * sx), h = (int)Math.Ceiling(HeightPt * sy);
        Box = new Rectangle((int)Math.Round(xFraction * pixels.Width - w/2f),
            (int)Math.Round(yFraction * pixels.Height - 4 * sy - h), w, h);
        var guard = Rectangle.Inflate(Box, (int)Math.Ceiling(2*sx), (int)Math.Ceiling(2*sy));
        Safe = false;
        if (!new Rectangle(0, 0, pixels.Width, pixels.Height).Contains(guard)) return;
        for (int y = guard.Top; y < guard.Bottom; y++)
            for (int x = guard.Left; x < guard.Right; x++)
            {
                var color = pixels.GetPixel(x, y);
                if (color.Red != 255 || color.Green != 255 || color.Blue != 255) return;
            }
        Safe = true;
    }

    public iText.Kernel.Geom.Rectangle PdfBox() => new(Left + Box.Left * Width / Page.Width,
        Bottom + (Page.Height - Box.Bottom) * Height / Page.Height,
        Box.Width * Width / Page.Width, Box.Height * Height / Page.Height);
    public byte[] StampBytes()
    {
        using var stream = new MemoryStream();
        Stamp.Save(stream, ImageFormat.Png);
        return stream.ToArray();
    }
    public void Dispose() { Page.Dispose(); Stamp.Dispose(); pixels.Dispose(); }
}
internal sealed class UserError(string message) : Exception(message);
