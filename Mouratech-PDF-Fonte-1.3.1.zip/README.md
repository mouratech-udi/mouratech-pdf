# Mouratech PDF

Leitor e assinador de PDFs para Windows de 64 bits. Edição pública de teste, versão 1.3.1.

## Baixar
[Baixar Mouratech PDF para Windows x64](https://github.com/mouratech-udi/mouratech-pdf/releases/latest/download/Mouratech-PDF-Windows-x64.msi). O projeto está em src e as licenças em Licencas. Para consultar as versões, abra **Releases**, escolha a versão mais recente e baixe **Mouratech-PDF-Windows-x64.msi**. Execute o instalador e abra **Mouratech PDF** pelo menu Iniciar.

## Recursos
Leia PDFs com miniaturas, zoom e busca por texto. Use Ferramentas para destacar trechos, inserir ou remover notas, unir, dividir e reorganizar páginas ou proteger uma cópia com senha. Insira texto ou uma assinatura por imagem. Para assinar digitalmente, selecione um certificado A1 compatível instalado no Windows. A assinatura individual ou em lote gera cópias assinadas e preserva os originais. O processamento ocorre no computador do usuário.

[Consultar o guia de uso](src/LEIA-ME.md) · [Consultar a licença](LICENSE.md)

Para relatar um problema, descreva os passos e a versão do Windows. Use arquivos fictícios como exemplo e mantenha dados pessoais, certificados e chaves privadas fora de relatos públicos.



