using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using iText.Bouncycastle.X509;
using iText.Commons.Bouncycastle.Cert;
using iText.Forms.Form.Element;
using iText.IO.Image;
using iText.Kernel.Pdf;
using iText.Signatures;
using Org.BouncyCastle.X509;

namespace Mouratech;

internal sealed record Identity(X509Certificate2 Certificate)
{
    public override string ToString() => $"{Certificate.GetNameInfo(X509NameType.SimpleName,false)}  ·  até {Certificate.NotAfter:d}";
    public static bool Eligible(X509Certificate2 cert)
    {
        if (!cert.HasPrivateKey || DateTime.Now < cert.NotBefore || DateTime.Now > cert.NotAfter ||
            cert.PublicKey.Oid.Value != "1.2.840.113549.1.1.1") return false;
        var usage = cert.Extensions.OfType<X509KeyUsageExtension>().FirstOrDefault();
        if (usage != null && (usage.KeyUsages & (X509KeyUsageFlags.DigitalSignature | X509KeyUsageFlags.NonRepudiation)) == 0) return false;
        var policies = cert.Extensions["2.5.29.32"];
        if (policies == null) return false;
        var list = new AsnReader(policies.RawData, AsnEncodingRules.DER).ReadSequence();
        while (list.HasData)
        {
            var id = list.ReadSequence().ReadObjectIdentifier();
            if (id.StartsWith("2.16.76.1.2.1.", StringComparison.Ordinal)) return true;
        }
        return false;
    }
}

internal sealed class WindowsSignature(RSA key) : IExternalSignature
{
    public string GetDigestAlgorithmName() => "SHA-256";
    public string GetSignatureAlgorithmName() => "RSA";
    public ISignatureMechanismParams GetSignatureMechanismParameters() => null!;
    public byte[] Sign(byte[] bytes) => key.SignData(bytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
}

internal static class Signing
{
    const string Field = "MouratechAssinatura";
    public static byte[] Create(Layout layout, X509Certificate2 cert)
    {
        if (!layout.Safe || !Identity.Eligible(cert)) throw new UserError("Confira o certificado e escolha uma área livre.");
        using var chain = new X509Chain();
        chain.ChainPolicy.DisableCertificateDownloads = true;
        chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
        if (!chain.Build(cert)) throw new UserError("O Windows não confirmou a cadeia local. Confira as autoridades instaladas e a validade.");
        return CreateWithChain(layout, cert, chain.ChainElements.Select(e => e.Certificate));
    }
    internal static byte[] CreateWithChain(Layout layout, X509Certificate2 cert, IEnumerable<X509Certificate2> chain)
    {
        if (!layout.Safe) throw new UserError("Carimbo fora da área livre.");
        using var key = cert.GetRSAPrivateKey() ?? throw new UserError("O Windows não disponibilizou a chave de assinatura.");
        IX509Certificate[] publicChain = chain.Select(c => (IX509Certificate)new X509CertificateBC(new X509CertificateParser().ReadCertificate(c.RawData))).ToArray();
        var signedAt = DateTimeOffset.Now;
        layout.DrawStamp(cert, signedAt);
        var appearance = new SignatureFieldAppearance(Field).SetContent(ImageDataFactory.Create(layout.StampBytes()));
        var props = new SignerProperties().SetClaimedSignDate(signedAt.LocalDateTime).SetFieldName(Field).SetPageNumber(layout.PageNumber)
            .SetPageRect(layout.PdfBox()).SetSignatureAppearance(appearance)
            .SetCertificationLevel(AccessPermissions.NO_CHANGES_PERMITTED);
        using var output = new MemoryStream();
        using var reader = new PdfReader(new MemoryStream(layout.Bytes));
        var signer = new PdfPadesSigner(reader, output);
        signer.SetStampingProperties(new StampingProperties().UseAppendMode());
        signer.SignWithBaselineBProfile(props, publicChain, new WindowsSignature(key));
        var signed = output.ToArray();
        if (!Verify(signed, cert)) throw new UserError("A conferência de integridade falhou.");
        return signed;
    }
    public static bool Verify(byte[] data, X509Certificate2? expected = null,string? password=null)
    {
        using var doc = Pages.Read(data,password);
        var signatures = new SignatureUtil(doc);
        if (!signatures.GetSignatureNames().SequenceEqual(new[]{Field}) || !signatures.SignatureCoversWholeDocument(Field)) return false;
        var cms = signatures.ReadSignatureData(Field);
        return cms.VerifySignatureIntegrityAndAuthenticity() && (expected == null || expected.RawData.SequenceEqual(cms.GetSigningCertificate().GetEncoded()));
    }

    public static string Save(string original, Layout layout, X509Certificate2 cert, string destination, byte[] baseline)
        => Save(original,layout,cert,destination,baseline,Create);

    internal static string Save(string original, Layout layout, X509Certificate2 cert, string destination, byte[] baseline,
        Func<Layout,X509Certificate2,byte[]> sign)
    {
        using var source = File.Open(original, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (!SHA256.HashData(source).SequenceEqual(SHA256.HashData(baseline)))
            throw new UserError("O original mudou. Abra novamente e confira a prévia.");
        
        if (File.Exists(destination)) throw new UserError("A cópia assinada já existe nesta pasta. Preserve-a ou mova-a antes de continuar.");
        var signed = sign(layout,cert);
        var temp = Path.Combine(Path.GetDirectoryName(destination)!, "." + Guid.NewGuid() + ".tmp");
        try
        {
            using (var f = new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)) { f.Write(signed); f.Flush(true); }
            if (!Verify(File.ReadAllBytes(temp),cert)) throw new UserError("Falha ao conferir a cópia gravada.");
            File.Move(temp,destination);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
        return destination;
    }
}



