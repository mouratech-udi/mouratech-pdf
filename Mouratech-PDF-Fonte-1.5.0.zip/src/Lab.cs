using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Font;
using PageSize = iText.Kernel.Geom.PageSize;
using iText.Signatures;

namespace Mouratech;

internal static class Lab
{
    // Isolated fixture: no store access, imported credentials or user documents.
    public static int Run(string directory)
    {
        if (Directory.Exists(directory) || File.Exists(directory)) return 2;
        Directory.CreateDirectory(directory);
        try
        {
            using var file=new MemoryStream();
            using(var doc=new PdfDocument(new PdfWriter(file)))
            {
                doc.AddNewPage(PageSize.A4);doc.AddNewPage(PageSize.A4);
                var canvas=new PdfCanvas(doc.AddNewPage(PageSize.A4));
                var font=PdfFontFactory.CreateFont();
                canvas.BeginText().SetFontAndSize(font,12).MoveText(85,360).ShowText("Conclusao ficticia").EndText();
                canvas.MoveTo(230,163).LineTo(400,163).Stroke();
                canvas.BeginText().SetFontAndSize(font,10).MoveText(245,147).ShowText("Profissional ficticio - CRM TESTE").EndText();
            }
            var input=file.ToArray();
            var marked=PdfTools.Annotate(input,2,new RectangleF(.1f,.2f,.4f,.03f),null);
            var noted=PdfTools.Annotate(marked,2,new RectangleF(.6f,.2f,.03f,.03f),"Rever este trecho.");
            using(var annotations=Pages.Read(noted))
            {
                var entries=annotations.GetPage(2).GetAnnotations();
                if(entries.Count<2 || !entries.Any(a=>a.GetContents()?.ToUnicodeString()=="Rever este trecho."))
                    throw new Exception("Nota ou marca-texto ausente.");
            }
            var sheets=new[]{new PdfTools.Sheet(noted,"Teste A",2),new PdfTools.Sheet(input,"Teste B",3)};
            var twoNotes=PdfTools.Annotate(noted,2,new RectangleF(.4f,.4f,.03f,.03f),"Manter esta nota.");
            var afterRemoval=PdfTools.RemoveNote(twoNotes,2,0);
            using(var check=Pages.Read(afterRemoval))
            {
                var remaining=check.GetPage(2).GetAnnotations();
                if(remaining.OfType<iText.Kernel.Pdf.Annot.PdfTextAnnotation>().Single().GetContents()?.ToUnicodeString()!="Manter esta nota." ||
                    !remaining.Any(a=>a.GetSubtype().Equals(PdfName.Highlight)))throw new Exception("Remoção seletiva de nota incorreta.");
            }
            var merged=PdfTools.Assemble(sheets);
            using(var reopened=Pages.Read(merged))
                if(reopened.GetNumberOfPages()!=2 || reopened.GetPage(1).GetAnnotations().Count<2 ||
                    !iText.Kernel.Pdf.Canvas.Parser.PdfTextExtractor.GetTextFromPage(reopened.GetPage(2)).Contains("ficticia"))
                    throw new Exception("Ordem ou conteúdo das páginas incorreto.");
            PdfTools.Split(Path.Combine(directory,"partes"),sheets);
            using(var part=Pages.Read(File.ReadAllBytes(Path.Combine(directory,"partes","parte-002.pdf"))))
                if(part.GetNumberOfPages()!=1)throw new Exception("Divisão incorreta.");
            string password=Convert.ToHexString(RandomNumberGenerator.GetBytes(16));
            var protectedPdf=PdfTools.Protect(merged,password);
            foreach(string? candidate in new string?[]{null,"incorreta"})
            {
                try{using var denied=Pages.Read(protectedPdf,candidate);throw new Exception("PDF abriu sem a senha correta.");}
                catch(iText.Kernel.Exceptions.BadPasswordException){}
            }
            using(var unlocked=Pages.Read(protectedPdf,password))
                if(unlocked.GetNumberOfPages()!=2 || !Pages.Locked(unlocked))throw new Exception("Proteção inválida.");
            using(var displayed=Pages.Render(protectedPdf,1,72,password))
                if(displayed.Width<100)throw new Exception("Prévia protegida inválida.");
            var edited=Pages.Insert(input,2,new PointF(.2f,.2f),"Texto de teste\nSegunda linha",null,14);
            using(var editedDoc=Pages.Read(edited))
            {
                var text=iText.Kernel.Pdf.Canvas.Parser.PdfTextExtractor.GetTextFromPage(editedDoc.GetPage(2));
                if(!text.Contains("Segunda linha") || Pages.Locked(editedDoc))throw new Exception("text edit");
            }
            using var graphic=new Bitmap(80,24);
            using(var brush=Graphics.FromImage(graphic)){brush.Clear(Color.Navy);}
            using var png=new MemoryStream();
            graphic.Save(png,System.Drawing.Imaging.ImageFormat.Png);
            var illustrated=Pages.Insert(edited,1,new PointF(.3f,.3f),null,png.ToArray(),100);
            using(var rendered=Pages.Render(illustrated,1,72))
                if(rendered.GetPixel((int)(rendered.Width*.3)+3,(int)(rendered.Height*.3)+3).B<80 ||
                    rendered.GetPixel((int)(rendered.Width*.3)+3,(int)(rendered.Height*.3)+3).R>100)
                    throw new Exception("image placement");
            string copy=Path.Combine(directory,"editado.pdf");
            Pages.Write(copy,edited,null);Pages.Write(copy,illustrated,edited);
            if(!File.ReadAllBytes(copy).SequenceEqual(illustrated))throw new Exception("save");
            using(var combined=new Layout(illustrated))
            {
                combined.Place(.52f,.802f);
                if(!combined.Safe)throw new Exception("sign after edit");
            }
            using var layout=new Layout(input);
            layout.Place(.52f,.83f);
            if(layout.Safe)throw new Exception("overlap");
            layout.Place(.52f,.802f);
            if(!layout.Safe)throw new Exception("placement");
            using var rsa=RSA.Create(3072);
            var request=new CertificateRequest("CN=Laboratorio ficticio Mouratech",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
            using var cert=request.CreateSelfSigned(DateTimeOffset.Now.AddDays(-1),DateTimeOffset.Now.AddDays(1));
            if(Identity.Eligible(cert))throw new Exception("policy");
            foreach(int count in new[]{1,2,4})
            {
                using var fixture=new MemoryStream();
                using(var doc=new PdfDocument(new PdfWriter(fixture)))
                    for(int i=0;i<count;i++)doc.AddNewPage(i==0?PageSize.A5:PageSize.A4);
                var bytes=fixture.ToArray();
                using(var defaultPage=new Layout(bytes))
                    if(defaultPage.PageNumber!=Math.Min(3,count))throw new Exception("Página padrão incorreta.");
                foreach(int number in new[]{1,count}.Distinct())
                {
                    using var selected=new Layout(bytes,number);
                    selected.Place(.52f,.802f);
                    var signedBytes=Signing.CreateWithChain(selected,cert,[cert]);
                    using var doc=new PdfDocument(new PdfReader(new MemoryStream(signedBytes)));
                    if(!Signing.Verify(signedBytes,cert))throw new Exception("Integridade na página escolhida.");
                    for(int p=1;p<=count;p++)
                    {
                        bool hasSignature=doc.GetPage(p).GetAnnotations().Any(a=>a.GetPdfObject().GetAsName(PdfName.FT)?.Equals(PdfName.Sig)==true);
                        if(hasSignature!=(p==number))throw new Exception("Assinatura gravada na página errada.");
                    }
                    var batchPath=Path.Combine(directory,$"pagina-{count}-{number}.pdf");
                    File.WriteAllBytes(batchPath,bytes);
                    var reviewed=new ReviewedFile(batchPath,SHA256.HashData(bytes),new PointF(.52f,.802f),cert.Thumbprint,number);
                    reviewed.Sign(cert,(l,c)=>{
                        if(l.PageNumber!=number)throw new Exception("Lote perdeu a página revisada.");
                        return Signing.CreateWithChain(l,c,[c]);
                    });
                }
                try { using var invalid=new Layout(bytes,count+1);throw new Exception("Página inválida aceita."); }
                catch(UserError) { }
            }
            var result=Signing.CreateWithChain(layout,cert,[cert]);
            var hits=FindText.In(edited,"tEsTe");
            if(!hits.Any(h=>h.Page==2 && h.Area.Width>0) || !hits.Any(h=>h.Page==3) || FindText.In(input,".*").Count!=0)
                throw new Exception("Busca literal, página ou destaque incorreto.");
            foreach(var sample in new[]{"lote-a","lote-b"})
            {
                var filePath=Path.Combine(directory,sample+".pdf");
                File.WriteAllBytes(filePath,input);
                var review=new ReviewedFile(filePath,SHA256.HashData(input),new PointF(.52f,.802f),cert.Thumbprint);
                byte[] LabSign(Layout l,X509Certificate2 c)=>Signing.CreateWithChain(l,c,[c]);
                review.Sign(cert,LabSign);
                if(!Signing.Verify(File.ReadAllBytes(review.Destination),cert) || !File.ReadAllBytes(filePath).SequenceEqual(input))
                    throw new Exception("Resultado do lote inválido.");
                try{review.Sign(cert,LabSign);throw new Exception("Cópia sobrescrita.");}catch(UserError){}
                File.WriteAllBytes(filePath,edited);
                try{review.Sign(cert,LabSign);throw new Exception("Revisão desatualizada aceita.");}catch(UserError){}
            }
            using(var originalPage=Pages.Render(input,3,144))
            using(var signedPage=Pages.Render(result,3,144))
            {
                var area=layout.Box;
                int changed=0;
                for(int y=area.Top*2/3;y<area.Bottom*2/3;y++)
                    for(int x=area.Left*2/3;x<area.Right*2/3;x++)
                        if(originalPage.GetPixel(x,y)!=signedPage.GetPixel(x,y))changed++;
                if(changed<50)throw new Exception("Carimbo ausente na renderização da página assinada.");
            }
            if(!result.AsSpan(0,input.Length).SequenceEqual(input))throw new Exception("original");
            using(var signed=new PdfDocument(new PdfReader(new MemoryStream(result))))
            {
                if(!Pages.Locked(signed))throw new Exception("signed PDF editing protection");
                var sig=new SignatureUtil(signed).GetSignatureDictionary("MouratechAssinatura");
                if(sig.GetAsName(PdfName.SubFilter)?.GetValue()!="ETSI.CAdES.detached" ||
                    signed.GetCatalog().GetPdfObject().GetAsDictionary(PdfName.Perms)?.GetAsDictionary(PdfName.DocMDP)==null)
                    throw new Exception("PDF profile");
            }
            var modified=(byte[])result.Clone(); modified[12]^=1;
            if(Signing.Verify(modified) || Signing.Verify([..result,32])) throw new Exception("tampering");
            File.WriteAllBytes(Path.Combine(directory,"ficticio.pdf"),input);
            File.WriteAllBytes(Path.Combine(directory,"ficticio_assinado.pdf"),result);
            return 0;
        }
        catch(Exception e){ File.WriteAllText(Path.Combine(directory,"falha.txt"),e.ToString());return 1;}
    }
}

