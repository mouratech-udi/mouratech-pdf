using System.Text.RegularExpressions;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Listener;

namespace Mouratech;

internal sealed record Hit(int Page,RectangleF Area);
internal static class FindText
{
    public static List<Hit> In(byte[] bytes,string term,string? password=null)
    {
        var hits=new List<Hit>();
        if(string.IsNullOrWhiteSpace(term))return hits;
        using var doc=Pages.Read(bytes,password);
        string pattern="(?i)"+Regex.Escape(term.Trim());
        for(int i=1;i<=doc.GetNumberOfPages();i++)
        {
            var page=doc.GetPage(i);
            var crop=page.GetCropBox();
            var strategy=new RegexBasedLocationExtractionStrategy(pattern);
            new PdfCanvasProcessor(strategy).ProcessPageContent(page);
            foreach(var location in strategy.GetResultantLocations())
            {
                var r=location.GetRectangle();
                float x=(r.GetLeft()-crop.GetLeft())/crop.GetWidth(),y=(crop.GetTop()-r.GetTop())/crop.GetHeight();
                float w=r.GetWidth()/crop.GetWidth(),h=r.GetHeight()/crop.GetHeight();
                var area=page.GetRotation() switch{
                    90=>new RectangleF(1-y-h,x,h,w),180=>new RectangleF(1-x-w,1-y-h,w,h),
                    270=>new RectangleF(y,1-x-w,h,w),_=>new RectangleF(x,y,w,h)};
                hits.Add(new Hit(i,area));
            }
        }
        return hits;
    }
}

