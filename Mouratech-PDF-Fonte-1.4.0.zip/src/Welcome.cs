namespace Mouratech;

internal sealed class Welcome : Form
{
    public Welcome()
    {
        Text="Iniciando Mouratech PDF";FormBorderStyle=FormBorderStyle.None;
        StartPosition=FormStartPosition.CenterScreen;ShowInTaskbar=false;
        AutoScaleMode=AutoScaleMode.Dpi;AutoScaleDimensions=new SizeF(96,96);
        ClientSize=new Size(650,280);BackColor=Brand.Navy;
        using var stream=typeof(Welcome).Assembly.GetManifestResourceStream("Mouratech.Logo")!;
        using var image=Image.FromStream(stream);
        var logo=new PictureBox{Bounds=new Rectangle(0,0,188,276),Padding=new Padding(17),
            SizeMode=PictureBoxSizeMode.Zoom,BackColor=Color.FromArgb(248,248,248),Image=new Bitmap(image),AccessibleName="Logotipo Mouratech"};
        Controls.Add(logo);
        void Line(string value,int y,int height,float size,FontStyle style,Color color)
        {
            Controls.Add(new Label{Text=value,Bounds=new Rectangle(211,y,426,height),ForeColor=color,
                Font=new Font("Segoe UI",size,style),TextAlign=ContentAlignment.MiddleLeft});
        }
        var version=typeof(Welcome).Assembly.GetName().Version!;
        Line("Mouratech PDF",12,43,21,FontStyle.Bold,Color.White);
        Line($"Versão {version.ToString(3)}",56,24,10,FontStyle.Regular,Color.LightSteelBlue);
        Line("Leitura, busca e impressão",94,24,11,FontStyle.Regular,Color.White);
        Line("Texto, marca-texto e notas",119,24,11,FontStyle.Regular,Color.White);
        Line("União, divisão e organização de páginas",144,24,11,FontStyle.Regular,Color.White);
        Line("Assinatura por imagem ou certificado digital",169,24,11,FontStyle.Regular,Color.White);
        Line("Assinatura em lote e proteção por senha",194,24,11,FontStyle.Regular,Color.White);
        Line("Desenvolvido pela Mouratech para seus clientes",236,25,10,FontStyle.Regular,Color.LightSteelBlue);
        Controls.Add(new Panel{Dock=DockStyle.Bottom,Height=4,BackColor=Brand.Blue});
        Disposed+=(_,_)=>logo.Image?.Dispose();
    }
}
