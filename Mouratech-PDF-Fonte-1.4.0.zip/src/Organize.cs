namespace Mouratech;

internal sealed class Organize : Form
{
    readonly ListBox list=new(){Dock=DockStyle.Fill,SelectionMode=SelectionMode.MultiExtended};
    readonly PictureBox preview=new(){Dock=DockStyle.Right,Width=265,SizeMode=PictureBoxSizeMode.Zoom,BackColor=Brand.Canvas};
    readonly HashSet<string> originals=new(StringComparer.OrdinalIgnoreCase);
    readonly string firstName;
    public Organize(string? path,byte[] current)
    {
        Text="Unir, dividir e organizar páginas";StartPosition=FormStartPosition.CenterParent;Size=new(920,580);
        firstName=path==null?"documento":Path.GetFileNameWithoutExtension(path);
        var actions=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,WrapContents=true};
        var bottom=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=46};
        Controls.Add(list);Controls.Add(preview);Controls.Add(actions);Controls.Add(bottom);
        void Button(FlowLayoutPanel panel,string label,Action run)
        {
            var b=new Button{AutoSize=true,Text=label};Brand.Button(b);panel.Controls.Add(b);
            b.Click+=(_,_)=>{try{run();}catch(UserError e){MessageBox.Show(this,e.Message,Text);}catch(Exception){MessageBox.Show(this,"Não foi possível concluir. Confira o arquivo e a pasta escolhida.",Text);}};
        }
        Button(actions,"Adicionar PDFs…",()=>{
            using var dlg=new OpenFileDialog{Filter="Documento PDF|*.pdf",Multiselect=true};
            if(dlg.ShowDialog(this)==DialogResult.OK)foreach(var f in dlg.FileNames)Add(f,File.ReadAllBytes(f));
        });
        Button(actions,"Subir",()=>MoveOne(-1));Button(actions,"Descer",()=>MoveOne(1));
        Button(actions,"Remover",()=>{foreach(int i in list.SelectedIndices.Cast<int>().Reverse().ToArray())list.Items.RemoveAt(i);});
        Button(bottom,"Salvar PDF organizado…",()=>Export(false));
        Button(bottom,"Extrair seleção…",()=>Export(true));
        Button(bottom,"Dividir por página…",()=>{
            using var dlg=new FolderBrowserDialog{Description="Escolha onde criar a pasta com um PDF por página"};
            if(dlg.ShowDialog(this)!=DialogResult.OK)return;
            string folder=Path.Combine(dlg.SelectedPath,firstName+"_partes");
            PdfTools.Split(folder,list.Items.Cast<PdfTools.Sheet>());MessageBox.Show(this,"Partes gravadas em "+folder,Text);
        });
        list.SelectedIndexChanged+=(_,_)=>{
            var old=preview.Image;preview.Image=null;old?.Dispose();
            if(list.SelectedItem is PdfTools.Sheet s)preview.Image=Pages.Render(s.Bytes,s.Page,60);
        };
        FormClosed+=(_,_)=>preview.Image?.Dispose();
        if(path!=null)Add(path,current);
    }
    void Add(string path,byte[] data)
    {
        using var doc=Pages.Read(data);PdfTools.Editable(doc);originals.Add(Path.GetFullPath(path));
        for(int n=1;n<=doc.GetNumberOfPages();n++)list.Items.Add(new PdfTools.Sheet(data,Path.GetFileName(path),n));
        if(list.SelectedIndex<0)list.SelectedIndex=0;
    }
    void MoveOne(int delta)
    {
        if(list.SelectedIndices.Count!=1)throw new UserError("Selecione uma página para mover.");
        int i=list.SelectedIndex,j=i+delta;if(j<0||j>=list.Items.Count)return;
        var sheet=list.Items[i];list.Items.RemoveAt(i);list.Items.Insert(j,sheet);list.SelectedIndex=j;
    }
    void Export(bool selected)
    {
        var sheets=selected?list.SelectedItems.Cast<PdfTools.Sheet>():list.Items.Cast<PdfTools.Sheet>();
        using var dlg=new SaveFileDialog{Filter="Documento PDF|*.pdf",FileName=firstName+(selected?"_extrato":"_organizado")+".pdf"};
        if(dlg.ShowDialog(this)!=DialogResult.OK)return;
        if(originals.Contains(Path.GetFullPath(dlg.FileName))||File.Exists(dlg.FileName))throw new UserError("Escolha um novo nome para a cópia.");
        Pages.Write(dlg.FileName,PdfTools.Assemble(sheets),null);MessageBox.Show(this,"PDF salvo em "+dlg.FileName,Text);
    }
}
