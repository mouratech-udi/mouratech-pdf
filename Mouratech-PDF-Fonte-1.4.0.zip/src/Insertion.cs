namespace Mouratech;

internal sealed class Insertion : Form
{
    public byte[]? Result {get;private set;}
    readonly PictureBox preview=new(){Dock=DockStyle.Fill,SizeMode=PictureBoxSizeMode.Zoom,BackColor=Color.Gainsboro};
    readonly TextBox editor=new(){Multiline=true,Width=254,Height=130,ScrollBars=ScrollBars.Vertical};
    readonly NumericUpDown size=new(){Minimum=6,Maximum=72,Value=12,Width=90};
    readonly Button apply=new(){Text="Aplicar",Width=254,Enabled=false};
    readonly byte[] source;
    readonly int page;
    readonly byte[]? image;
    PointF? point;
    public Insertion(byte[] bytes,int number,byte[]? graphic)
    {
        source=bytes;page=number;image=graphic;
        Text=graphic==null?"Inserir texto":"Assinatura por imagem";
        Size=new Size(960,770);MinimumSize=new Size(700,510);StartPosition=FormStartPosition.CenterParent;
        var options=new FlowLayoutPanel{Dock=DockStyle.Right,Width=286,Padding=new Padding(12),FlowDirection=FlowDirection.TopDown,WrapContents=false};
        Controls.Add(preview);Controls.Add(options);
        preview.BackColor=Brand.Canvas;options.BackColor=Color.White;options.ForeColor=Brand.Navy;
        void Label(string s,int h)=>options.Controls.Add(new Label{Text=s,Width=254,Height=h});
        if(graphic==null){Label("Texto a acrescentar à página",24);options.Controls.Add(editor);Label("Tamanho da letra (pt)",26);}
        else{Label("Largura da assinatura (pt)",30);size.Maximum=480;size.Minimum=12;size.Value=115;}
        options.Controls.Add(size);Label("Clique na página para marcar o canto superior esquerdo. Confira a prévia e aplique.",68);
        options.Controls.Add(apply);var cancel=new Button{Text="Cancelar",Width=254,DialogResult=DialogResult.Cancel};options.Controls.Add(cancel);CancelButton=cancel;
        Brand.Button(apply,true);Brand.Button(cancel);
        preview.Image=Pages.Render(bytes,number,120);
        preview.MouseClick+=(_,e)=>{
            var bmp=preview.Image!;
            float s=Math.Min((float)preview.Width/bmp.Width,(float)preview.Height/bmp.Height);
            float w=bmp.Width*s,h=bmp.Height*s;
            var p=new PointF((e.X-(preview.Width-w)/2)/w,(e.Y-(preview.Height-h)/2)/h);
            if(p.X<0 || p.Y<0 || p.X>=1 || p.Y>=1)return;
            point=p;UpdatePreview();
        };
        editor.TextChanged+=(_,_)=>InvalidatePlacement();size.ValueChanged+=(_,_)=>InvalidatePlacement();
        apply.Click+=(_,_)=>{if(Result!=null)DialogResult=DialogResult.OK;};
        FormClosed+=(_,_)=>preview.Image?.Dispose();
    }
    void InvalidatePlacement()
    {
        if(Result!=null){var old=preview.Image;preview.Image=Pages.Render(source,page,120);old?.Dispose();}
        Result=null;apply.Enabled=false;
    }
    void UpdatePreview()
    {
        InvalidatePlacement();
        if(point==null || (image==null && string.IsNullOrWhiteSpace(editor.Text)))return;
        try
        {
            var next=Pages.Insert(source,page,point.Value,editor.Text,image,(int)size.Value);
            var bitmap=Pages.Render(next,page,120);
            var old=preview.Image;preview.Image=bitmap;old?.Dispose();Result=next;apply.Enabled=true;
        }
        catch(UserError ex){MessageBox.Show(this,ex.Message,Text);}
        catch(Exception){MessageBox.Show(this,"Não foi possível inserir o conteúdo nesta página.",Text);}
    }
}
