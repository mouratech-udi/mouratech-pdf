using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace Mouratech;

internal sealed record ReviewedFile(string Path,byte[] Digest,PointF Placement,string Thumbprint)
{
    public string Destination => System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Path)!,
        System.IO.Path.GetFileNameWithoutExtension(Path)+"_assinado.pdf");

    public void Sign(X509Certificate2 certificate)
        => Sign(certificate,Signing.Create);

    internal void Sign(X509Certificate2 certificate,Func<Layout,X509Certificate2,byte[]> sign)
    {
        if(certificate.Thumbprint!=Thumbprint)throw new UserError("O certificado mudou após a revisão.");
        var bytes=File.ReadAllBytes(Path);
        if(!SHA256.HashData(bytes).SequenceEqual(Digest))throw new UserError("O arquivo mudou após a revisão.");
        using var layout=new Layout(bytes);
        layout.Place(Placement.X,Placement.Y);
        Signing.Save(Path,layout,certificate,Destination,bytes,sign);
    }
}
internal static class Batch
{
    public static void Run(Form owner)
    {
        using var select=new OpenFileDialog{Title="Selecionar PDFs para o lote",Filter="Documento PDF|*.pdf",Multiselect=true,RestoreDirectory=true};
        if(select.ShowDialog(owner)!=DialogResult.OK)return;
        var files=select.FileNames.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        var reviews=new List<ReviewedFile>();
        var report=new List<string>();
        string? thumbprint=null;
        for(int i=0;i<files.Length;i++)
        {
            string path=files[i];
            try
            {
                var bytes=File.ReadAllBytes(path);
                using var review=new Desk(path,bytes,bytes,$"Revisar documento {i+1} de {files.Length}",thumbprint);
                var result=review.ShowDialog(owner);
                if(result==DialogResult.Ignore){report.Add($"{path} — pulado");continue;}
                if(result!=DialogResult.OK || review.Reviewed==null)return;
                thumbprint=review.Reviewed.Thumbprint;reviews.Add(review.Reviewed);
            }
            catch(IOException){report.Add($"{path} — falha de leitura");}
            catch(UnauthorizedAccessException){report.Add($"{path} — acesso negado");}
        }
        if(reviews.Count>0)
        {
            using var store=new X509Store(StoreName.My,StoreLocation.CurrentUser);
            store.Open(OpenFlags.ReadOnly|OpenFlags.OpenExistingOnly);
            var matches=store.Certificates.Find(X509FindType.FindByThumbprint,thumbprint!,false);
            if(matches.Count==0)throw new UserError("O certificado revisado não está mais disponível.");
            using var certificate=matches[0];
            if(MessageBox.Show(owner,$"Assinar {reviews.Count} arquivo(s) com {certificate.GetNameInfo(X509NameType.SimpleName,false)}? As cópias serão gravadas na pasta de cada original com o sufixo _assinado.","Confirmar lote",MessageBoxButtons.OKCancel)!=DialogResult.OK)return;
            foreach(var item in reviews)
            {
                try{item.Sign(certificate);report.Add($"{item.Destination} — assinado e conferido");}
                catch(UserError e){report.Add($"{item.Path} — {e.Message}");}
                catch(Exception){report.Add($"{item.Path} — falha ao assinar ou gravar");}
            }
        }
        using var dialog=new Form{Text="Resultado do lote",Width=790,Height=420,StartPosition=FormStartPosition.CenterParent};
        dialog.Controls.Add(new TextBox{Dock=DockStyle.Fill,Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=false,Text=string.Join(Environment.NewLine,report)});
        dialog.ShowDialog(owner);
    }
}

