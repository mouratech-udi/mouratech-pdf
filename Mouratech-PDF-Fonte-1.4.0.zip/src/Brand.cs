namespace Mouratech;

internal static class Brand
{
    internal static readonly Color Navy=Color.FromArgb(13,37,65);
    internal static readonly Color Blue=Color.FromArgb(0,91,177);
    internal static readonly Color Silver=Color.FromArgb(228,234,241);
    internal static readonly Color Canvas=Color.FromArgb(214,221,229);

    internal static void Button(Button button,bool primary=false)
    {
        button.FlatStyle=FlatStyle.Flat;
        button.BackColor=primary?Blue:Color.White;
        button.ForeColor=primary?Color.White:Navy;
        button.FlatAppearance.BorderColor=primary?Blue:Color.FromArgb(177,191,207);
        button.FlatAppearance.MouseOverBackColor=primary?Navy:Silver;
    }

    internal static void Toolbar(ToolStrip strip)
    {
        strip.Renderer=new ToolbarRenderer();
        strip.BackColor=Navy;strip.ForeColor=Color.White;
    }
    private sealed class ToolbarRenderer : ToolStripSystemRenderer
    {
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            if(e.ToolStrip is ToolStripDropDown){base.OnRenderToolStripBackground(e);return;}
            e.Graphics.Clear(Navy);
        }
        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
        {
            if(e.Item.Selected || e.Item.Pressed)
                using(var brush=new SolidBrush(Blue))e.Graphics.FillRectangle(brush,new Rectangle(Point.Empty,e.Item.Size));
        }
        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            if(e.ToolStrip is not ToolStripDropDown)e.TextColor=e.Item.Enabled?Color.White:Color.LightSteelBlue;
            base.OnRenderItemText(e);
        }
    }
}
