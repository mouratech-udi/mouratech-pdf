param(
    [Parameter(Mandatory)][string]$Publicacao,
    [Parameter(Mandatory)][string]$Saida,
    [string]$Wix='wix',
    [string]$Versao='1.4.0'
)
$ErrorActionPreference='Stop'
$pub=(Resolve-Path -LiteralPath $Publicacao).Path
$dest=[IO.Path]::GetFullPath($Saida)
$tempDir=Join-Path ([IO.Path]::GetTempPath()) ("mouratech-build-"+[guid]::NewGuid())
New-Item -ItemType Directory -Path $tempDir | Out-Null
function StableId([string]$key){
    $bytes=[Text.Encoding]::UTF8.GetBytes("Mouratech.PDF/"+$key.ToLowerInvariant())
    return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).Substring(0,32)
}
function EscapeXml([string]$value){[Security.SecurityElement]::Escape($value)}
$parts=[Collections.Generic.List[string]]::new()
function AddFolder([IO.DirectoryInfo]$folder,[string]$relative){
    foreach($file in $folder.GetFiles()){
        $key=$relative+$file.Name
        $id=StableId $key
        $guid=[Guid]::ParseExact($id,'N')
        $fileId=if($key -eq 'Mouratech.Assinador.exe'){'MainExe'}else{"F$id"}
        $parts.Add(('<Component Id="C{0}" Guid="{1}"><File Id="{2}" Source="{3}" KeyPath="yes" /></Component>' -f $id,$guid,$fileId,(EscapeXml $file.FullName)))
    }
    foreach($child in $folder.GetDirectories()){
        $sub=$relative+$child.Name+'/'
        $parts.Add(('<Directory Id="D{0}" Name="{1}">' -f (StableId $sub),(EscapeXml $child.Name)))
        AddFolder $child $sub
        $parts.Add('</Directory>')
    }
}
AddFolder ([IO.DirectoryInfo]$pub) ''
$xml=@"
<Wix xmlns="http://wixtoolset.org/schemas/v4/wxs">
<Package Name="Mouratech PDF" Manufacturer="Mouratech" Version="$Versao" Language="1046" UpgradeCode="C325B45E-5890-4216-8C33-F0CCBAB937A0" Scope="perUser" InstallerVersion="500">
<MajorUpgrade DowngradeErrorMessage="Uma versão mais recente já está instalada." Schedule="afterInstallInitialize"/>
<MediaTemplate EmbedCab="yes" CompressionLevel="medium"/>
<Icon Id="AppIcon" SourceFile="$(EscapeXml (Join-Path $pub 'Fonte/Mouratech.ico'))"/>
<Property Id="ARPPRODUCTICON" Value="AppIcon"/>
<StandardDirectory Id="LocalAppDataFolder"><Directory Id="ProgramsDir" Name="Programs"><Directory Id="INSTALLFOLDER" Name="Mouratech PDF">
$($parts -join [Environment]::NewLine)
<Component Id="Integration" Guid="C0116774-7902-441F-931B-FD8D55CCBC1F">
<Shortcut Id="ReaderShortcut" Directory="ProgramMenuFolder" Name="Mouratech PDF" Target="[#MainExe]" WorkingDirectory="INSTALLFOLDER" Icon="AppIcon"/>
<RegistryValue Root="HKCU" Key="Software\Classes\Mouratech.PDF.Document" Type="string" Value="Documento PDF – Mouratech" KeyPath="yes"/>
<RegistryValue Root="HKCU" Key="Software\Classes\Mouratech.PDF.Document\shell\open\command" Type="string" Value="&quot;[#MainExe]&quot; &quot;%1&quot;"/>
<RegistryValue Root="HKCU" Key="Software\Classes\Mouratech.PDF.Document\DefaultIcon" Type="string" Value="&quot;[#MainExe]&quot;,0"/>
<RegistryValue Root="HKCU" Key="Software\Classes\.pdf\OpenWithProgids" Name="Mouratech.PDF.Document" Type="string" Value=""/>
<RegistryValue Root="HKCU" Key="Software\Mouratech\PDF\Capabilities" Name="ApplicationName" Type="string" Value="Mouratech PDF"/>
<RegistryValue Root="HKCU" Key="Software\Mouratech\PDF\Capabilities" Name="ApplicationDescription" Type="string" Value="Leitor e assinador de PDF"/>
<RegistryValue Root="HKCU" Key="Software\Mouratech\PDF\Capabilities\FileAssociations" Name=".pdf" Type="string" Value="Mouratech.PDF.Document"/>
<RegistryValue Root="HKCU" Key="Software\RegisteredApplications" Name="Mouratech PDF" Type="string" Value="Software\Mouratech\PDF\Capabilities"/>
</Component></Directory></Directory></StandardDirectory>
<StandardDirectory Id="ProgramMenuFolder"/>
<Feature Id="Reader" Title="Mouratech PDF" Level="1"><ComponentRef Id="Integration"/>
COMPONENT_REFS
</Feature></Package></Wix>
"@
$refs=foreach($line in $parts){if($line -match '^<Component Id="([^"]+)"'){ '<ComponentRef Id="'+$Matches[1]+'"/>' }}
$xml=$xml.Replace('COMPONENT_REFS',($refs -join [Environment]::NewLine))
$source=Join-Path $tempDir 'reader.wxs'
Set-Content $source $xml -Encoding utf8
& $Wix build -arch x64 -intermediateFolder $tempDir -pdbtype none -o $dest $source
if($LASTEXITCODE){throw "Falha ao criar o instalador ($LASTEXITCODE)."}




