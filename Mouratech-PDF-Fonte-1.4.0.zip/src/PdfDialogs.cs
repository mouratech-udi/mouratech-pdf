namespace Mouratech;
internal static class PdfDialogs
{
    public static string? Input(Form owner,string title,bool password=false,bool confirm=false)
    {
        using var dialog=new Form{Text=title,StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,
            MinimizeBox=false,MaximizeBox=false,ClientSize=new Size(380,password?155:205)};
        var panel=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(12)};
        dialog.Controls.Add(panel);
        var input=new TextBox{Width=344,Multiline=!password,Height=password?26:108,UseSystemPasswordChar=password};
        panel.Controls.Add(input);
        var repeat=new TextBox{Width=344,UseSystemPasswordChar=true,PlaceholderText="Confirme a senha"};
        if(confirm)panel.Controls.Add(repeat);
        var ok=new Button{Text="Confirmar",AutoSize=true};Brand.Button(ok,true);panel.Controls.Add(ok);
        ok.Click+=(_,_)=>{
            if(input.Text.Length==0 || (confirm && input.Text!=repeat.Text)){MessageBox.Show(dialog,"Confira os campos e tente novamente.");return;}
            dialog.DialogResult=DialogResult.OK;
        };
        if(password)dialog.AcceptButton=ok;
        return dialog.ShowDialog(owner)==DialogResult.OK?input.Text:null;
    }
}
