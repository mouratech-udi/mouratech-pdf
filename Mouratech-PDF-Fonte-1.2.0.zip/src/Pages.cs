using iText.IO.Image;
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Signatures;
using PDFtoImage;
using SkiaSharp;

namespace Mouratech;

internal static class Pages
{
    internal static PdfDocument Read(byte[] bytes) => new(new PdfReader(new MemoryStream(bytes)));
    internal static bool Locked(PdfDocument doc) => doc.GetReader().IsEncrypted() || new SignatureUtil(doc).GetSignatureNames().Count>0;
    internal static Bitmap Render(byte[] bytes,int number,int dpi)
    {
        using var pixels=Conversion.ToImage(bytes,number-1,options:new RenderOptions(Dpi:dpi,WithAnnotations:true,WithFormFill:true));
        using var png=pixels.Encode(SKEncodedImageFormat.Png,100);
        using var input=png.AsStream();
        using var image=new Bitmap(input);
        return new Bitmap(image);
    }
    internal static byte[] Insert(byte[] bytes,int number,PointF at,string? text,byte[]? image,int size)
    {
        using var result=new MemoryStream();
        using(var doc=new PdfDocument(new PdfReader(new MemoryStream(bytes)),new PdfWriter(result),new StampingProperties().UseAppendMode()))
        {
            if(Locked(doc))throw new UserError("Este documento está protegido ou assinado.");
            var page=doc.GetPage(number);
            var bounds=page.GetCropBox();
            if(page.GetRotation()!=0 || !bounds.EqualsWithEpsilon(page.GetMediaBox()) ||
                page.GetPdfObject().GetAsNumber(PdfName.UserUnit)?.FloatValue() is not (null or 1f))
                throw new UserError("A inserção requer uma página sem rotação ou recorte especial.");
            var x=bounds.GetLeft()+at.X*bounds.GetWidth();
            var top=bounds.GetTop()-at.Y*bounds.GetHeight();
            var canvas=new PdfCanvas(page,true);
            if(image!=null)
            {
                var data=ImageDataFactory.Create(image);
                float w=size,h=w*data.GetHeight()/data.GetWidth();
                if(x+w>bounds.GetRight() || top-h<bounds.GetBottom())throw new UserError("A imagem ultrapassa a página. Reduza a largura ou escolha outro ponto.");
                canvas.AddImageWithTransformationMatrix(data,w,0,0,h,x,top-h);
            }
            else
            {
                var font=PdfFontFactory.CreateFont();
                var lines=text!.Replace("\r","").Split('\n');
                if(lines.Any(line=>line.Any(c=>!font.ContainsGlyph(c)) || x+font.GetWidth(line,size)>bounds.GetRight()) ||
                    top-lines.Length*size*1.35f<bounds.GetBottom())
                    throw new UserError("O texto contém caracteres incompatíveis ou ultrapassa a página. Ajuste a posição, o tamanho ou as quebras de linha.");
                canvas.BeginText().SetFontAndSize(font,size);
                foreach(var line in lines){canvas.SetTextMatrix(x,top-size).ShowText(line);top-=size*1.35f;}
                canvas.EndText();
            }
        }
        return result.ToArray();
    }

    internal static void Write(string destination,byte[] bytes,byte[]? expected)
    {
        string temp=Path.Combine(Path.GetDirectoryName(destination)!,"."+Guid.NewGuid()+".tmp");
        try
        {
            using(var file=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){file.Write(bytes);file.Flush(true);}
            if(expected!=null)
            {
                using var source=new FileStream(destination,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete);
                if(!System.Security.Cryptography.SHA256.HashData(source).SequenceEqual(System.Security.Cryptography.SHA256.HashData(expected)))
                    throw new UserError("O arquivo mudou no disco. Use Salvar como e escolha outro nome.");
                File.Replace(temp,destination,null);
            }
            else File.Move(temp,destination);
        }
        finally{if(File.Exists(temp))File.Delete(temp);}
    }
}
