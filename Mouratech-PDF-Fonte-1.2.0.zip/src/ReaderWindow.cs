using System.Drawing.Printing;
using System.Drawing.Imaging;
using iText.Forms;
using iText.Signatures;
using System.Security.Cryptography.X509Certificates;

namespace Mouratech;

internal sealed class ReaderWindow : Form, IMessageFilter
{
    readonly ToolStrip bar=new(){GripStyle=ToolStripGripStyle.Hidden};
    readonly Panel viewport=new(){Dock=DockStyle.Fill,AutoScroll=true,BackColor=Color.FromArgb(225,230,233)};
    readonly PictureBox paper=new(){SizeMode=PictureBoxSizeMode.StretchImage,BackColor=Color.White,Visible=false};
    readonly Panel side=new(){Dock=DockStyle.Left,Width=137,BackColor=Color.White};
    readonly ListBox thumbs=new(){Dock=DockStyle.Fill,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=116,BorderStyle=BorderStyle.None,IntegralHeight=false};
    readonly Dictionary<int,Bitmap> cache=new();
    readonly FlowLayoutPanel footer=new(){Dock=DockStyle.Bottom,Height=40,FlowDirection=FlowDirection.LeftToRight,Padding=new Padding(5,3,0,0)};
    readonly Label pageInfo=new(){AutoSize=true,Margin=new Padding(4,6,10,0)};
    readonly TrackBar zoom=new(){Minimum=25,Maximum=300,TickStyle=TickStyle.None,Width=130,Height=29,AutoSize=false};
    readonly Label percent=new(){AutoSize=true,Margin=new Padding(4,6,8,0)};
    readonly List<ToolStripItem> fileCommands=new(),editCommands=new();
    readonly ToolStripButton save;
    readonly ToolStripButton undo;
    readonly ToolStrip search=new(){GripStyle=ToolStripGripStyle.Hidden,Visible=false};
    readonly ToolStripTextBox query=new(){Width=210};
    readonly ToolStripLabel found=new();
    List<Hit> hits=new();
    string? searched;
    int hitIndex=-1;
    readonly ToolStripDropDownButton signatures=new("Assinaturas digitais"){Visible=false};
    Point? dragOrigin;
    Point dragScroll;
    byte[] bytes=[],baseline=[];
    byte[]? beforeEdit;
    string? path;
    int page,count;
    int wheelRemainder;
    bool locked,fit=true,syncZoom;
    bool Dirty=>!ReferenceEquals(bytes,baseline);
    public ReaderWindow(string? initial)
    {
        Text="Mouratech PDF";Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        Size=new Size(1120,850);MinimumSize=new Size(780,540);StartPosition=FormStartPosition.CenterScreen;
        Font=new Font("Segoe UI",10);KeyPreview=true;
        Brand.Toolbar(bar);Brand.Toolbar(search);viewport.BackColor=Brand.Canvas;
        footer.BackColor=Brand.Silver;footer.ForeColor=Brand.Navy;thumbs.ForeColor=Brand.Navy;
        viewport.Controls.Add(paper);side.Controls.Add(thumbs);
        Controls.Add(viewport);Controls.Add(side);Controls.Add(footer);Controls.Add(search);Controls.Add(bar);
        ToolStripButton Tool(string name,Action action,List<ToolStripItem>? group=null)
        {
            var button=new ToolStripButton(name);button.Click+=(_,_)=>Guard(action);bar.Items.Add(button);group?.Add(button);return button;
        }
        Tool("Abrir",Open);
        Tool("Buscar",OpenSearch,fileCommands);
        search.Items.Add(new ToolStripLabel("Buscar no PDF"));search.Items.Add(query);
        search.Items.Add("Anterior",null,(_,_)=>Guard(()=>Find(-1)));
        search.Items.Add("Próxima",null,(_,_)=>Guard(()=>Find(1)));
        search.Items.Add(found);search.Items.Add("Fechar",null,(_,_)=>CloseSearch());
        query.TextChanged+=(_,_)=>ResetSearch();
        query.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;Guard(()=>Find(e.Shift?-1:1));}
            else if(e.KeyCode==Keys.Escape){e.SuppressKeyPress=true;CloseSearch();}};
        paper.Paint+=(_,e)=>{
            if(hitIndex<0 || hits[hitIndex].Page!=page)return;
            var a=hits[hitIndex].Area;
            using var brush=new SolidBrush(Color.FromArgb(110,255,190,0));
            e.Graphics.FillRectangle(brush,a.X*paper.Width,a.Y*paper.Height,a.Width*paper.Width,a.Height*paper.Height);
        };
        Tool("Inserir texto",()=>Insert(false),editCommands);
        undo=Tool("Desfazer",Undo);
        save=Tool("Salvar",()=>Save(false));
        Tool("Salvar como",()=>Save(true),fileCommands);
        Tool("Imprimir",Print,fileCommands);
        bar.Items.Add(new ToolStripSeparator());
        Tool("Assinar por imagem",()=>Insert(true),editCommands);
        Tool("Assinar digitalmente",Sign,editCommands);
        Tool("Assinar lote",()=>Batch.Run(this));
        Tool("Verificar",()=>MessageBox.Show(this,Signing.Verify(bytes)
            ? "Assinatura Mouratech íntegra e com cobertura de todo o arquivo."
            : "Nenhuma assinatura individual Mouratech íntegra confirmada neste PDF.","Verificação local"),fileCommands);
        bar.Items.Add(signatures);
        paper.MouseDown+=(_,e)=>{
            if(e.Button!=MouseButtons.Left)return;
            dragOrigin=paper.PointToScreen(e.Location);dragScroll=viewport.AutoScrollPosition;
            paper.Capture=true;paper.Cursor=Cursors.SizeAll;
        };
        paper.MouseMove+=(_,e)=>{
            if(dragOrigin is not Point origin)return;
            var current=paper.PointToScreen(e.Location);
            viewport.AutoScrollPosition=new Point(Math.Max(0,-dragScroll.X+origin.X-current.X),
                Math.Max(0,-dragScroll.Y+origin.Y-current.Y));
        };
        paper.MouseUp+=(_,e)=>{
            if(e.Button!=MouseButtons.Left || dragOrigin is not Point origin)return;
            int dy=paper.PointToScreen(e.Location).Y-origin.Y;
            bool wholePage=!viewport.VerticalScroll.Visible;
            paper.Capture=false;
            if(wholePage && Math.Abs(dy)>60*DeviceDpi/96)Guard(()=>Go(page+(dy<0?1:-1)));
        };
        paper.Cursor=Cursors.Hand;
        paper.MouseCaptureChanged+=(_,_)=>{if(!paper.Capture){dragOrigin=null;paper.Cursor=Cursors.Hand;}};
        void Button(string label,Action action)
        {
            var b=new Button{Text=label,AutoSize=true,Height=28};Brand.Button(b);b.Click+=(_,_)=>Guard(action);footer.Controls.Add(b);
        }
        Button("Miniaturas",()=>{side.Visible=!side.Visible;SizePage();});
        Button("‹",()=>Go(page-1));footer.Controls.Add(pageInfo);Button("›",()=>Go(page+1));
        footer.Controls.Add(zoom);footer.Controls.Add(percent);Button("Ajustar página",()=>{fit=true;SizePage();});
        zoom.ValueChanged+=(_,_)=>{if(!syncZoom){fit=false;SizePage();}};
        viewport.Resize+=(_,_)=>SizePage();
        thumbs.DrawItem+=DrawThumb;
        thumbs.SelectedIndexChanged+=(_,_)=>Guard(()=>Go(thumbs.SelectedIndex+1));
        KeyDown+=(_,e)=>{
            Action? a=e.KeyData switch{Keys.Control|Keys.O=>Open,Keys.Control|Keys.S=>()=>Save(false),
                Keys.Control|Keys.Shift|Keys.S=>()=>Save(true),Keys.Control|Keys.P=>Print,Keys.Control|Keys.Z=>Undo,
                Keys.PageDown=>()=>Go(page+1),Keys.PageUp=>()=>Go(page-1),_=>null};
            if(a!=null){e.SuppressKeyPress=true;Guard(a);}
        };
        FormClosing+=(_,e)=>{if(!MayLeave())e.Cancel=true;};
        Load+=(_,_)=>Application.AddMessageFilter(this);
        FormClosed+=(_,_)=>{Application.RemoveMessageFilter(this);ClearThumbs();paper.Image?.Dispose();};
        RefreshState();if(initial!=null)Shown+=(_,_)=>Guard(()=>LoadFile(Path.GetFullPath(initial)));
    }
    protected override bool ProcessCmdKey(ref Message msg,Keys keys)
    {
        if(keys==(Keys.Control|Keys.F)){OpenSearch();return true;}
        return base.ProcessCmdKey(ref msg,keys);
    }
    void ResetSearch(){searched=null;hits.Clear();hitIndex=-1;found.Text="";paper.Invalidate();}
    void CloseSearch(){search.Visible=false;ResetSearch();viewport.Focus();}
    void OpenSearch(){if(count==0)return;search.Visible=true;query.Focus();query.SelectAll();}
    void Find(int direction)
    {
        if(string.IsNullOrWhiteSpace(query.Text))return;
        if(searched!=query.Text){hits=FindText.In(bytes,query.Text);searched=query.Text;hitIndex=-1;}
        if(hits.Count==0){found.Text="Nenhum resultado";return;}
        hitIndex=hitIndex<0?(direction>0?0:hits.Count-1):(hitIndex+direction+hits.Count)%hits.Count;
        var hit=hits[hitIndex];Go(hit.Page);
        var scroll=viewport.AutoScrollPosition;
        viewport.AutoScrollPosition=new Point(Math.Max(0,paper.Left-scroll.X+(int)(hit.Area.X*paper.Width)-viewport.Width/3),
            Math.Max(0,paper.Top-scroll.Y+(int)(hit.Area.Y*paper.Height)-viewport.Height/3));
        found.Text=$"{hitIndex+1} de {hits.Count}";paper.Invalidate();
    }
    public bool PreFilterMessage(ref Message message)
    {
        const int MouseWheel=0x020A;
        if(message.Msg!=MouseWheel || paper.Image==null || !Enabled || Control.FromChildHandle(message.HWnd)?.FindForm()!=this)return false;
        var packed=message.LParam.ToInt64();
        var cursor=viewport.PointToClient(new Point(unchecked((short)packed),unchecked((short)(packed>>16))));
        if(!viewport.ClientRectangle.Contains(cursor))return false;

        wheelRemainder+=unchecked((short)(message.WParam.ToInt64()>>16));
        int steps=wheelRemainder/SystemInformation.MouseWheelScrollDelta;
        wheelRemainder%=SystemInformation.MouseWheelScrollDelta;
        if(steps==0)return true;

        int target=Math.Clamp(zoom.Value+steps*10,zoom.Minimum,zoom.Maximum);
        if(target==zoom.Value)return true;
        double x=Math.Clamp((cursor.X-paper.Left)/(double)paper.Width,0,1);
        double y=Math.Clamp((cursor.Y-paper.Top)/(double)paper.Height,0,1);
        zoom.Value=target;
        var scroll=viewport.AutoScrollPosition;
        viewport.AutoScrollPosition=new Point(
            Math.Max(0,paper.Left-scroll.X+(int)Math.Round(x*paper.Width)-cursor.X),
            Math.Max(0,paper.Top-scroll.Y+(int)Math.Round(y*paper.Height)-cursor.Y));
        return true;
    }
    void Guard(Action action)
    {
        try{action();}
        catch(UserError e){MessageBox.Show(this,e.Message,"Mouratech PDF");}
        catch(Exception){MessageBox.Show(this,"Não foi possível concluir. Confira o arquivo, as permissões e o dispositivo selecionado.","Mouratech PDF");}
    }
    bool MayLeave()
    {
        if(!Dirty)return true;
        var choice=MessageBox.Show(this,"Salvar as alterações antes de continuar?","Mouratech PDF",MessageBoxButtons.YesNoCancel);
        if(choice==DialogResult.Yes){Guard(()=>Save(false));return !Dirty;}
        return choice==DialogResult.No;
    }
    void Open()
    {
        using var dialog=new OpenFileDialog{Filter="Documento PDF|*.pdf",RestoreDirectory=true};
        if(dialog.ShowDialog(this)==DialogResult.OK && MayLeave())LoadFile(dialog.FileName);
    }
    void LoadFile(string file)
    {
        var data=File.ReadAllBytes(file);
        using var doc=Pages.Read(data);
        int total=doc.GetNumberOfPages();bool readOnly=Pages.Locked(doc);
        var first=Pages.Render(data,1,144);
        CloseSearch();query.Clear();
        count=total;locked=readOnly;path=file;bytes=baseline=data;beforeEdit=null;page=1;fit=true;
        ClearThumbs();
        thumbs.BeginUpdate();thumbs.Items.Clear();
        for(int i=1;i<=count;i++)thumbs.Items.Add(i);
        thumbs.SelectedIndex=0;thumbs.EndUpdate();
        Display(first);RefreshState();
        ShowSignatures(doc);
    }
    void ShowSignatures(iText.Kernel.Pdf.PdfDocument doc)
    {
        signatures.DropDownItems.Clear();
        var names=new SignatureUtil(doc).GetSignatureNames();
        signatures.Visible=names.Count>0;
        if(names.Count==0)return;
        signatures.Text=$"Assinaturas digitais ({names.Count})";
        var form=PdfAcroForm.GetAcroForm(doc,false);
        foreach(var name in names)
        {
            var widget=form?.GetField(name)?.GetWidgets().FirstOrDefault();
            var signedPage=widget?.GetPage();
            int number=signedPage==null?0:doc.GetPageNumber(signedPage);
            var label=number>0?$"Página {number} · {name}":name;
            signatures.DropDownItems.Add(label,null,(_,_)=>Guard(()=>{
                if(number>0)Go(number);
                using var source=Pages.Read(bytes);
                var util=new SignatureUtil(source);
                var sig=util.ReadSignatureData(name);
                using var cert=X509CertificateLoader.LoadCertificate(sig.GetSigningCertificate().GetEncoded());
                string summary=sig.VerifySignatureIntegrityAndAuthenticity()?"Integridade da revisão assinada confirmada.":"Falha na verificação da integridade.";
                MessageBox.Show(this,$"Titular: {cert.GetNameInfo(X509NameType.SimpleName,false)}\nEmissor: {cert.GetNameInfo(X509NameType.SimpleName,true)}\n\n{summary}\nCobertura do arquivo inteiro: {(util.SignatureCoversWholeDocument(name)?"sim":"não")}.","Assinatura digital");
            }));
        }
    }
    void Display(Bitmap next)
    {
        var old=paper.Image;paper.Image=next;old?.Dispose();paper.Visible=true;
        wheelRemainder=0;viewport.AutoScrollPosition=Point.Empty;SizePage();
    }
    void SizePage()
    {
        var image=paper.Image;if(image==null)return;
        float natural=DeviceDpi/144f;
        float scale=fit?Math.Min((viewport.ClientSize.Width-28f)/image.Width,(viewport.ClientSize.Height-28f)/image.Height):zoom.Value/100f*natural;
        scale=Math.Max(.02f,scale);
        var size=new Size(Math.Max(1,(int)(image.Width*scale)),Math.Max(1,(int)(image.Height*scale)));
        if(paper.Size!=size)paper.Size=size;
        paper.Location=new Point(viewport.AutoScrollPosition.X+Math.Max(8,(viewport.ClientSize.Width-size.Width)/2),
            viewport.AutoScrollPosition.Y+Math.Max(8,(viewport.ClientSize.Height-size.Height)/2));
        var value=(int)Math.Round(scale/natural*100);
        if(fit){syncZoom=true;zoom.Value=Math.Clamp(value,zoom.Minimum,zoom.Maximum);syncZoom=false;}
        percent.Text=value+"%";
    }
    void Go(int target)
    {
        if(target<1 || target>count || target==page)return;
        var bitmap=Pages.Render(bytes,target,144);page=target;
        thumbs.SelectedIndex=page-1;Display(bitmap);RefreshState();
    }
    void ClearThumbs(){foreach(var img in cache.Values)img.Dispose();cache.Clear();}
    void DrawThumb(object? sender,DrawItemEventArgs e)
    {
        if(e.Index<0 || e.Index>=count)return;
        int number=e.Index+1;e.DrawBackground();
        if(!cache.TryGetValue(number,out var img))
        {
            try{img=Pages.Render(bytes,number,18);}catch{return;}
            if(cache.Count>=40){int key=cache.Keys.First();cache[key].Dispose();cache.Remove(key);}cache[number]=img;
        }
        float scale=Math.Min((e.Bounds.Width-16f)/img.Width,88f/img.Height);
        int w=(int)(img.Width*scale),h=(int)(img.Height*scale);
        var rect=new Rectangle(e.Bounds.X+(e.Bounds.Width-w)/2,e.Bounds.Y+5,w,h);
        e.Graphics.DrawImage(img,rect);e.Graphics.DrawRectangle(Pens.Silver,rect);
        TextRenderer.DrawText(e.Graphics,number.ToString(),Font,new Rectangle(e.Bounds.Left,e.Bounds.Bottom-22,e.Bounds.Width,20),e.ForeColor,TextFormatFlags.HorizontalCenter);
    }
    void RefreshState()
    {
        Text=(path!=null?Path.GetFileName(path)+(Dirty?" *":"")+"  —  ":"")+"Mouratech PDF";
        pageInfo.Text=count>0?$"Página {page} de {count}":"Nenhum PDF aberto";
        foreach(var item in fileCommands)item.Enabled=count>0;
        foreach(var item in editCommands)item.Enabled=count>0 && !locked;
        save.Enabled=Dirty;undo.Enabled=beforeEdit!=null;zoom.Enabled=count>0;
    }
    void Save(bool choose)
    {
        if(path==null || (!choose&&!Dirty))return;
        string dest=path;
        if(choose)
        {
            using var dlg=new SaveFileDialog{Filter="Documento PDF|*.pdf",InitialDirectory=Path.GetDirectoryName(path),FileName=Path.GetFileName(path)};
            if(dlg.ShowDialog(this)!=DialogResult.OK)return;dest=dlg.FileName;
        }
        bool same=StringComparer.OrdinalIgnoreCase.Equals(path,dest);
        byte[]? expected=same?baseline:File.Exists(dest)?File.ReadAllBytes(dest):null;
        if(!same && expected!=null){using var existing=Pages.Read(expected);if(Pages.Locked(existing))throw new UserError("Escolha outro nome para preservar o documento assinado ou protegido existente.");}
        Pages.Write(dest,bytes,expected);path=dest;baseline=bytes;beforeEdit=null;RefreshState();
    }
    void Insert(bool signature)
    {
        if(locked||path==null)return;
        byte[]? image=null;
        if(signature)
        {
            using var pick=new OpenFileDialog{Filter="Imagem da assinatura|*.png;*.jpg;*.jpeg",RestoreDirectory=true};
            if(pick.ShowDialog(this)!=DialogResult.OK)return;image=File.ReadAllBytes(pick.FileName);
        }
        using var dialog=new Insertion(bytes,page,image);
        if(dialog.ShowDialog(this)!=DialogResult.OK || dialog.Result==null)return;
        Apply(dialog.Result,true);
    }
    void Apply(byte[] data,bool remember)
    {
        var next=Pages.Render(data,page,144);ResetSearch();beforeEdit=remember?bytes:null;bytes=data;
        ClearThumbs();Display(next);thumbs.Invalidate();RefreshState();
    }
    void Undo(){if(beforeEdit!=null)Apply(beforeEdit,false);}
    void Sign()
    {
        if(path==null||locked)return;
        using var dialog=new Desk(path,bytes,baseline);
        if(dialog.ShowDialog(this)==DialogResult.OK && dialog.SavedPath!=null)LoadFile(dialog.SavedPath);
    }
    void Print()
    {
        if(path==null)return;
        using var job=new PrintDocument{DocumentName=Path.GetFileName(path),OriginAtMargins=false};
        using var dialog=new PrintDialog{Document=job,UseEXDialog=true,AllowSomePages=true};
        var settings=job.PrinterSettings;
        settings.MinimumPage=1;settings.MaximumPage=count;settings.FromPage=1;settings.ToPage=count;
        if(dialog.ShowDialog(this)!=DialogResult.OK)return;
        var configured=job.PrinterSettings;
        int current=configured.PrintRange==PrintRange.SomePages?configured.FromPage:1;
        int last=configured.PrintRange==PrintRange.SomePages?configured.ToPage:count;
        job.PrintPage+=(_,e)=>{
            using var bmp=Pages.Render(bytes,current,216);
            var bounds=e.MarginBounds;float scale=Math.Min((float)bounds.Width/bmp.Width,(float)bounds.Height/bmp.Height);
            float w=bmp.Width*scale,h=bmp.Height*scale;
            e.Graphics!.DrawImage(bmp,bounds.X+(bounds.Width-w)/2,bounds.Y+(bounds.Height-h)/2,w,h);
            e.HasMorePages=++current<=last;
        };
        job.Print();
    }
}

