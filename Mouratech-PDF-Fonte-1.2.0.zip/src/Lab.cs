using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Font;
using PageSize = iText.Kernel.Geom.PageSize;
using iText.Signatures;

namespace Mouratech;

internal static class Lab
{
    // Isolated fixture: no store access, imported credentials or user documents.
    public static int Run(string directory)
    {
        if (Directory.Exists(directory) || File.Exists(directory)) return 2;
        Directory.CreateDirectory(directory);
        try
        {
            using var file=new MemoryStream();
            using(var doc=new PdfDocument(new PdfWriter(file)))
            {
                doc.AddNewPage(PageSize.A4);doc.AddNewPage(PageSize.A4);
                var canvas=new PdfCanvas(doc.AddNewPage(PageSize.A4));
                var font=PdfFontFactory.CreateFont();
                canvas.BeginText().SetFontAndSize(font,12).MoveText(85,360).ShowText("Conclusao ficticia").EndText();
                canvas.MoveTo(230,163).LineTo(400,163).Stroke();
                canvas.BeginText().SetFontAndSize(font,10).MoveText(245,147).ShowText("Profissional ficticio - CRM TESTE").EndText();
            }
            var input=file.ToArray();
            var edited=Pages.Insert(input,2,new PointF(.2f,.2f),"Texto de teste\nSegunda linha",null,14);
            using(var editedDoc=Pages.Read(edited))
            {
                var text=iText.Kernel.Pdf.Canvas.Parser.PdfTextExtractor.GetTextFromPage(editedDoc.GetPage(2));
                if(!text.Contains("Segunda linha") || Pages.Locked(editedDoc))throw new Exception("text edit");
            }
            using var graphic=new Bitmap(80,24);
            using(var brush=Graphics.FromImage(graphic)){brush.Clear(Color.Navy);}
            using var png=new MemoryStream();
            graphic.Save(png,System.Drawing.Imaging.ImageFormat.Png);
            var illustrated=Pages.Insert(edited,1,new PointF(.3f,.3f),null,png.ToArray(),100);
            using(var rendered=Pages.Render(illustrated,1,72))
                if(rendered.GetPixel((int)(rendered.Width*.3)+3,(int)(rendered.Height*.3)+3).B<80 ||
                    rendered.GetPixel((int)(rendered.Width*.3)+3,(int)(rendered.Height*.3)+3).R>100)
                    throw new Exception("image placement");
            string copy=Path.Combine(directory,"editado.pdf");
            Pages.Write(copy,edited,null);Pages.Write(copy,illustrated,edited);
            if(!File.ReadAllBytes(copy).SequenceEqual(illustrated))throw new Exception("save");
            using(var combined=new Layout(illustrated))
            {
                combined.Place(.52f,.802f);
                if(!combined.Safe)throw new Exception("sign after edit");
            }
            using var layout=new Layout(input);
            layout.Place(.52f,.83f);
            if(layout.Safe)throw new Exception("overlap");
            layout.Place(.52f,.802f);
            if(!layout.Safe)throw new Exception("placement");
            using var rsa=RSA.Create(3072);
            var request=new CertificateRequest("CN=Laboratorio ficticio Mouratech",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
            using var cert=request.CreateSelfSigned(DateTimeOffset.Now.AddDays(-1),DateTimeOffset.Now.AddDays(1));
            if(Identity.Eligible(cert))throw new Exception("policy");
            var result=Signing.CreateWithChain(layout,cert,[cert]);
            var hits=FindText.In(edited,"tEsTe");
            if(!hits.Any(h=>h.Page==2 && h.Area.Width>0) || !hits.Any(h=>h.Page==3) || FindText.In(input,".*").Count!=0)
                throw new Exception("Busca literal, página ou destaque incorreto.");
            foreach(var sample in new[]{"lote-a","lote-b"})
            {
                var filePath=Path.Combine(directory,sample+".pdf");
                File.WriteAllBytes(filePath,input);
                var review=new ReviewedFile(filePath,SHA256.HashData(input),new PointF(.52f,.802f),cert.Thumbprint);
                byte[] LabSign(Layout l,X509Certificate2 c)=>Signing.CreateWithChain(l,c,[c]);
                review.Sign(cert,LabSign);
                if(!Signing.Verify(File.ReadAllBytes(review.Destination),cert) || !File.ReadAllBytes(filePath).SequenceEqual(input))
                    throw new Exception("Resultado do lote inválido.");
                try{review.Sign(cert,LabSign);throw new Exception("Cópia sobrescrita.");}catch(UserError){}
                File.WriteAllBytes(filePath,edited);
                try{review.Sign(cert,LabSign);throw new Exception("Revisão desatualizada aceita.");}catch(UserError){}
            }
            using(var originalPage=Pages.Render(input,3,144))
            using(var signedPage=Pages.Render(result,3,144))
            {
                var area=layout.Box;
                int changed=0;
                for(int y=area.Top*2/3;y<area.Bottom*2/3;y++)
                    for(int x=area.Left*2/3;x<area.Right*2/3;x++)
                        if(originalPage.GetPixel(x,y)!=signedPage.GetPixel(x,y))changed++;
                if(changed<50)throw new Exception("Carimbo ausente na renderização da página assinada.");
            }
            if(!result.AsSpan(0,input.Length).SequenceEqual(input))throw new Exception("original");
            using(var signed=new PdfDocument(new PdfReader(new MemoryStream(result))))
            {
                if(!Pages.Locked(signed))throw new Exception("signed PDF editing protection");
                var sig=new SignatureUtil(signed).GetSignatureDictionary("MouratechAssinatura");
                if(sig.GetAsName(PdfName.SubFilter)?.GetValue()!="ETSI.CAdES.detached" ||
                    signed.GetCatalog().GetPdfObject().GetAsDictionary(PdfName.Perms)?.GetAsDictionary(PdfName.DocMDP)==null)
                    throw new Exception("PDF profile");
            }
            var modified=(byte[])result.Clone(); modified[12]^=1;
            if(Signing.Verify(modified) || Signing.Verify([..result,32])) throw new Exception("tampering");
            File.WriteAllBytes(Path.Combine(directory,"ficticio.pdf"),input);
            File.WriteAllBytes(Path.Combine(directory,"ficticio_assinado.pdf"),result);
            return 0;
        }
        catch(Exception e){ File.WriteAllText(Path.Combine(directory,"falha.txt"),e.ToString());return 1;}
    }
}

