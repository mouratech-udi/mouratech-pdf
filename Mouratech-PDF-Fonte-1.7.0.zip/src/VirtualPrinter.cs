using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace Mouratech;

internal sealed class VirtualPrinter : IDisposable
{
    internal const string PrinterName = "Mouratech PDF";
    internal static string SettingsPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Mouratech", "entrada-pdf.json");
    readonly System.Windows.Forms.Timer timer = new() { Interval = 2000 };
    readonly Dictionary<string, (long Size, DateTime Modified)> observed = new(StringComparer.OrdinalIgnoreCase);
    readonly Dictionary<string, (long Size, DateTime Modified)> delivered = new(StringComparer.OrdinalIgnoreCase);
    readonly Action<string> open;
    string? folder;

    internal VirtualPrinter(Action<string> open, string? inputFolder = null)
    {
        this.open = open;
        folder = inputFolder ?? ReadFolder();
        Reload();
        timer.Tick += (_, _) => Poll();
        timer.Start();
    }

    internal static string? ReadFolder()
    {
        try { return JsonSerializer.Deserialize<string>(File.ReadAllText(SettingsPath)); }
        catch (IOException) { return null; }
        catch (UnauthorizedAccessException) { return null; }
        catch (JsonException) { return null; }
    }

    internal void Reload()
    {
        observed.Clear();
        delivered.Clear();
        if (!Directory.Exists(folder)) return;
        // Existing documents stay in the inbox. Only newly saved PDFs open automatically.
        try
        {
            foreach (var file in new DirectoryInfo(folder!).EnumerateFiles("*.pdf"))
                delivered[file.FullName] = (file.Length, file.LastWriteTimeUtc);
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    internal void Poll()
    {
        if (!Directory.Exists(folder)) return;
        timer.Stop();
        try
        {
            foreach (var file in new DirectoryInfo(folder!).EnumerateFiles("*.pdf"))
            {
                if (file.Name.EndsWith("_assinado.pdf", StringComparison.OrdinalIgnoreCase)) continue;
                var stamp = (file.Length, file.LastWriteTimeUtc);
                if (delivered.TryGetValue(file.FullName, out var sent) && sent == stamp) continue;
                bool stable = observed.TryGetValue(file.FullName, out var previous) && previous == stamp;
                observed[file.FullName] = stamp;
                if (!stable || file.Length == 0) continue;
                try
                {
                    using (var input = new FileStream(file.FullName, FileMode.Open, FileAccess.Read, FileShare.None))
                    using (var buffer = new MemoryStream())
                    {
                        input.CopyTo(buffer);
                        using var pdf = Pages.Read(buffer.ToArray());
                        if (pdf.GetNumberOfPages() == 0) continue;
                    }
                    open(file.FullName);
                    delivered[file.FullName] = stamp;
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                catch (iText.Kernel.Exceptions.PdfException) { }
                catch (ArgumentException) { }
            }
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        finally { timer.Start(); }
    }

    internal static bool Configure(IWin32Window owner)
    {
        using var pick = new FolderBrowserDialog { Description = "Escolha a pasta em que salvará as impressões PDF", UseDescriptionForTitle = true,
            SelectedPath = ReadFolder() ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) };
        if (pick.ShowDialog(owner) != DialogResult.OK) return false;
        const string script = " $ErrorActionPreference='Stop'; $p=Get-Printer -Name 'Mouratech PDF' -ErrorAction SilentlyContinue; " +
            "if($p){if($p.DriverName -ne 'Microsoft Print To PDF' -or $p.PortName -ne 'PORTPROMPT:'){exit 2}}" +
            "else{Add-Printer -Name 'Mouratech PDF' -DriverName 'Microsoft Print To PDF' -PortName 'PORTPROMPT:'}";
        using var process = Process.Start(new ProcessStartInfo("powershell.exe")
        {
            Arguments = "-NoProfile -NonInteractive -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes(script)),
            UseShellExecute = false, CreateNoWindow = true
        }) ?? throw new UserError("Não foi possível iniciar a configuração da impressora.");
        if (!process.WaitForExit(20000)) throw new UserError("A instalação ainda está em andamento. Confira as impressoras do Windows e tente novamente.");
        if (process.ExitCode != 0) throw new UserError("O Windows não conseguiu criar a impressora Mouratech PDF. Confira se Microsoft Print to PDF está instalado e se sua conta pode adicionar impressoras.");
        Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
        string temporary = SettingsPath + "." + Guid.NewGuid() + ".tmp";
        try
        {
            File.WriteAllText(temporary, JsonSerializer.Serialize(pick.SelectedPath));
            File.Move(temporary, SettingsPath, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
        MessageBox.Show(owner, "Impressora Mouratech PDF pronta.\n\nAo imprimir, salve o PDF nesta pasta:\n" + pick.SelectedPath +
            "\n\nMantenha esta janela do Mouratech aberta ou minimizada. Os novos PDFs serão abertos automaticamente para conferência e assinatura.", "Impressora virtual");
        return true;
    }

    public void Dispose() { timer.Stop(); timer.Dispose(); }
}
