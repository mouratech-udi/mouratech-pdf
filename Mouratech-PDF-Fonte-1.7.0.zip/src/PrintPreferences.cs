using System.Drawing.Printing;
using System.Text.Json;

namespace Mouratech;

internal sealed record PrintPreferences(string Printer, string Paper, bool Landscape, short Copies)
{
    static string SettingsPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Mouratech", "impressao.json");

    internal static PrintPreferences? Load()
    {
        try { return JsonSerializer.Deserialize<PrintPreferences>(File.ReadAllText(SettingsPath)); }
        catch (IOException) { return null; }
        catch (UnauthorizedAccessException) { return null; }
        catch (JsonException) { return null; }
    }

    internal void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
        string temporary = SettingsPath + "." + Guid.NewGuid() + ".tmp";
        try
        {
            File.WriteAllText(temporary, JsonSerializer.Serialize(this));
            File.Move(temporary, SettingsPath, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }

    internal bool Apply(PrintDocument job)
    {
        if (string.IsNullOrWhiteSpace(Printer) || string.IsNullOrWhiteSpace(Paper)) return false;
        var settings = new PrinterSettings { PrinterName = Printer };
        if (!settings.IsValid) return false;
        var paper = settings.PaperSizes.Cast<PaperSize>().FirstOrDefault(p => p.PaperName == Paper);
        if (paper == null || Copies < 1 || Copies > settings.MaximumCopies) return false;
        settings.Copies = Copies;
        settings.PrintToFile = false;
        job.PrinterSettings = settings;
        job.DefaultPageSettings = new PageSettings(settings) { PaperSize = paper, Landscape = Landscape };
        return true;
    }

    internal static bool Configure(IWin32Window owner)
    {
        var saved = Load();
        using var window = new Form { Text = "Impressora preferida do Mouratech", ClientSize = new Size(440, 350),
            StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false, MinimizeBox = false, Font = new Font("Segoe UI", 10) };
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), FlowDirection = FlowDirection.TopDown, WrapContents = false };
        window.Controls.Add(panel);
        panel.Controls.Add(new Label { Text = "Escolha a impressora física usada para os documentos.", Width = 400, Height = 40 });
        var printers = new ComboBox { Width = 400, DropDownStyle = ComboBoxStyle.DropDownList };
        foreach (string name in PrinterSettings.InstalledPrinters) printers.Items.Add(name);
        panel.Controls.Add(printers);
        panel.Controls.Add(new Label { Text = "Papel", AutoSize = true });
        var papers = new ComboBox { Width = 400, DropDownStyle = ComboBoxStyle.DropDownList, DisplayMember = "PaperName" };
        panel.Controls.Add(papers);
        var landscape = new CheckBox { Text = "Orientação paisagem", Width = 400, Checked = saved?.Landscape ?? false };
        panel.Controls.Add(landscape);
        panel.Controls.Add(new Label { Text = "Quantidade de cópias", AutoSize = true });
        var copies = new NumericUpDown { Minimum = 1, Maximum = 999, Width = 100 };
        panel.Controls.Add(copies);
        var save = new Button { Text = "Salvar preferência", Width = 195, Height = 36 };
        Brand.Button(save, true);
        panel.Controls.Add(save);
        printers.SelectedIndexChanged += (_, _) =>
        {
            papers.Items.Clear();
            var settings = new PrinterSettings { PrinterName = printers.Text };
            foreach (PaperSize paper in settings.PaperSizes) papers.Items.Add(paper);
            var preferred = papers.Items.Cast<PaperSize>().FirstOrDefault(p => p.PaperName == saved?.Paper)
                ?? papers.Items.Cast<PaperSize>().FirstOrDefault(p => p.PaperName == settings.DefaultPageSettings.PaperSize.PaperName);
            papers.SelectedItem = preferred;
            if (papers.SelectedIndex < 0 && papers.Items.Count > 0) papers.SelectedIndex = 0;
            copies.Maximum = Math.Clamp((int)settings.MaximumCopies, 1, short.MaxValue);
            copies.Value = Math.Clamp(saved?.Copies ?? 1, 1, (int)copies.Maximum);
        };
        if (saved != null && printers.Items.Contains(saved.Printer)) printers.SelectedItem = saved.Printer;
        save.Click += (_, _) =>
        {
            if (printers.SelectedItem is not string printer || papers.SelectedItem is not PaperSize paper)
            { MessageBox.Show(window, "Selecione a impressora física e o papel."); return; }
            try
            {
                new PrintPreferences(printer, paper.PaperName, landscape.Checked, (short)copies.Value).Save();
                window.DialogResult = DialogResult.OK;
            }
            catch (Exception) { MessageBox.Show(window, "Não foi possível salvar a preferência nesta conta do Windows."); }
        };
        return window.ShowDialog(owner) == DialogResult.OK;
    }
}
