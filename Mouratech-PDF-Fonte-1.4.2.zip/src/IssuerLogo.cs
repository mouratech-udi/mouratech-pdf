using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using SkiaSharp;

namespace Mouratech;

internal static class IssuerLogo
{
    internal static Bitmap? Read(X509Certificate2? certificate)
    {
        var raw = certificate?.Extensions["1.3.6.1.5.5.7.1.12"]?.RawData;
        if (raw == null || raw.Length > 1024 * 1024) return null;
        try
        {
            var fields = new AsnReader(raw, AsnEncodingRules.DER).ReadSequence();
            var issuer = new Asn1Tag(TagClass.ContextSpecific, 1, true);
            while (fields.HasData && fields.PeekTag() != issuer) fields.ReadEncodedValue();
            if (!fields.HasData) return null;
            var direct = fields.ReadSequence(issuer).ReadSequence(new Asn1Tag(TagClass.ContextSpecific, 0, true));
            var images = direct.ReadSequence();
            while (images.HasData)
            {
                var details = images.ReadSequence().ReadSequence();
                string mime = details.ReadCharacterString(UniversalTagNumber.IA5String).ToLowerInvariant();
                if (mime is not ("image/png" or "image/jpeg" or "image/gif")) continue;
                var hashes = details.ReadSequence();
                var urls = details.ReadSequence();
                string prefix = $"data:{mime};base64,";
                while (urls.HasData)
                {
                    string uri = urls.ReadCharacterString(UniversalTagNumber.IA5String);
                    if (!uri.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                    byte[] data = Convert.FromBase64String(uri[prefix.Length..]);
                    if (!MatchesHash(hashes.Clone(), data)) continue;
                    using var codec = SKCodec.Create(new MemoryStream(data));
                    if (codec == null || codec.Info.Width <= 0 || codec.Info.Height <= 0 ||
                        (long)codec.Info.Width * codec.Info.Height > 4000000) continue;
                    using var decoded = SKBitmap.Decode(codec);
                    if (decoded == null) continue;
                    using var png = decoded.Encode(SKEncodedImageFormat.Png, 100);
                    using var stream = png.AsStream();
                    using var bitmap = new Bitmap(stream);
                    return new Bitmap(bitmap);
                }
            }
        }
        catch (AsnContentException) { }
        catch (FormatException) { }
        catch (ArgumentException) { }
        return null;
    }

    private static bool MatchesHash(AsnReader hashes, byte[] bytes)
    {
        while (hashes.HasData)
        {
            var pair = hashes.ReadSequence();
            var algorithm = pair.ReadSequence().ReadObjectIdentifier();
            var expected = pair.ReadOctetString();
            byte[]? actual = algorithm switch
            {
                "2.16.840.1.101.3.4.2.1" => SHA256.HashData(bytes),
                "2.16.840.1.101.3.4.2.2" => SHA384.HashData(bytes),
                "2.16.840.1.101.3.4.2.3" => SHA512.HashData(bytes),
                _ => null
            };
            if (actual != null && actual.AsSpan().SequenceEqual(expected)) return true;
        }
        return false;
    }
}
